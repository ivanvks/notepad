#include <libpq-fe.h>

// Подключение к базе данных
PGconn *conn = PQconnectdb("hostaddr=127.0.0.1 port=5432 dbname=mydatabase user=myuser password=mypassword");

// Получение дескриптора сокета
int socketDescriptor = PQsocket(conn);

// Использование дескриптора сокета, например:
if (socketDescriptor >= 0) {
    // Сокет действителен, делайте что-то с ним
} else {
    // Произошла ошибка
}

// Закрытие соединения
PQfinish(conn);

sudo apt-get install libpq-dev
#include <libpq-fe.h>

bool CSqlDatabase::openDataBase(const CSettings &sqlParam) {
    qDebug() << "openDataBase";

    // Установка параметров подключения к базе данных ASUV
    const char *host = sqlParam.asuvParam().value("host").toStdString().c_str();
    const char *port = sqlParam.asuvParam().value("port").toString().toStdString().c_str();
    const char *dbname = sqlParam.asuvParam().value("name").toString().toStdString().c_str();
    const char *user = sqlParam.asuvParam().value("user").toString().toStdString().c_str();
    const char *pass = sqlParam.asuvParam().value("pass").toString().toStdString().c_str();

    // Установка соединения с базой данных ASUV
    PGconn *conn = PQsetdbLogin(host, port, NULL, NULL, dbname, user, pass);
    if (PQstatus(conn) != CONNECTION_OK) {
        qDebug() << "Connection to database failed: " << PQerrorMessage(conn);
        PQfinish(conn);
        return false;
    }

    // Получение дескриптора сокета
    int socketDescriptor = PQsocket(conn);
    qDebug() << "Socket descriptor:" << socketDescriptor;

    // Здесь  использовать дескриптор сокета или выполнять другие операции с базой данных

    // Освобождение ресурсов
    PQfinish(conn);

    qDebug() << "openDataBase End";
    return true;
}

cmake_minimum_required(VERSION 3.0)
project(your_project_name)

# Найти библиотеку libpq
find_package(PostgreSQL REQUIRED)

# Добавить исполняемый файл вашего проекта
add_executable(your_executable_name your_source_files.cpp)

# Указать компилятору, что нужно включить заголовочные файлы libpq
target_include_directories(your_executable_name PRIVATE ${PostgreSQL_INCLUDE_DIRS})

# Указать компилятору, что нужно связать ваше приложение с библиотекой libpq
target_link_libraries(your_executable_name PRIVATE ${PostgreSQL_LIBRARIES})

