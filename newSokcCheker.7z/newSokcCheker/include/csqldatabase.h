#ifndef CSQLDATABASE_H
#define CSQLDATABASE_H

#include <QSqlQuery>
#include <QSqlError>
#include <QObject>
#include <QMap>
#include <QSqlDriver>
#include <QSocketNotifier>


#include "csettings.h"
#include <libpq-fe.h>

class CSqlDatabase : public QObject
{
    Q_OBJECT

    /// объект подключения к базе данных ASUV
    QSqlDatabase    mASUVDataBase_;
    /// объект подключения к базе данных POVZ
    QSqlDatabase    mPOVZDataBase_;
    /// инициализируем коллекцию таблиц классификаторов
    QMap < QString, QString > mKlassTableMap_;
    QString msgSubtypeTLK;
    // QStringList idLstKSI;
   // QStringList idLstKSIzip;
   // QSocketNotifier *m_socketNotifier;
    PGconn *conn;

public:

    /**
     * @brief CSqlDatabase - Конструктор класса работы с базой данных
     * @param type         - тип драйвера подключения к базе данных
     */
    CSqlDatabase( const QString &type = "QPSQL" );
    /**
     * @brief isOpenASUV - Возвращаем статус подключения к ASUV
     * @return           - статус подключения к ASUV
     */
    bool isOpenASUV();

    /**
     * @brief isOpenPOVZ - Возвращаем статус подключения к POVZ
     * @return           - статус подключения к POVZ
     */
    bool isOpenPOVZ();

    /**
     * @brief lastErrorASUV - Возвращаем информацию о последней ошибке, произошедшей в базе данных ASUV
     * @return              - информация о последней ошибке, произошедшей в базе данных ASUV
     */
    QString lastErrorASUV();

    /**
     * @brief lastErrorPOVZ - Возвращаем информацию о последней ошибке, произошедшей в базе данных POVZ
     * @return              - информация о последней ошибке, произошедшей в базе данных POVZ
     */
    QString lastErrorPOVZ();

    QString klassName( const QString &klass, const QString &kod );
//protected:
   // bool eventFilter(QObject *watched, QEvent *event) override;
signals:
    /**
     * @brief signalMSGVfsvData - Передача данных о ВФСВ
     * @param vfsvMsgs          - Данные о ВФСВ
     */
    void signalMSGVfsvData(const QVector < QByteArray >& vfsvMsgs);
    /**
     * @brief signalMSGVfsvData - Передача данных о ВФСВ для zip
     * @param vfsvMsgs          - Данные о ВФСВ для zip
     */
    void signalMSGVfsvDataZip(const QVector < QByteArray >& vfsvMsgs);
    /**
     * @brief signalMSGVfvpData - Передача данных о ВФВП для zip
     * @param vfsvMsgs          - Данные о ВФВП для zip
     */
    void signalMSGVfvpDataZip(const QVector < QByteArray >& vfvpMsgs);
    /**
     * @brief signalMSGKsiDataZip - Передача данных о КСИ
     * @param vfsvMsgs            - Данные о КСИ
     */
    void signalMSGKsiDataZip(const QByteArray &ksiMsgs);
    /**
     * @brief signalMSGVfvpData - Передача данных о ВФВП
     * @param vfvpMsgs          - Данные о ВФВП
     */
    void signalMSGVfvpData(const QVector < QByteArray >& vfvpMsgs);
    /**
     * @brief signalMSGKsiData - Передача данных о КСИ
     * @param vfsvMsgs          - Данные о КСИ
     */
    void signalMSGKsiData(const QByteArray &ksiMsgs);
   // void signalMSGKsiDataFS(const QVector < QByteArray >& ksiMsgs, int messageCount);
    //void signalMSGKsiDataUDP(const QVector < QByteArray >& ksiMsgs, int messageCount);
    //void signalMSGKsiDataTCP(const QVector < QByteArray >& ksiMsgs, int messageCount);
   // void signalMSGKsiDataTCP(const QByteArray & ksiMsgs, int messageCount);
  //  void signalMSGVfsvDataFS(const QVector < QByteArray >& vfsvMsgs);
  //  void signalMSGVfsvDataUDP(const QVector < QByteArray >& vfsvMsgs);
   // void signalMSGVfsvDataTCP(const QVector < QByteArray >& vfsvMsgs);
    /**
     * @brief signalMSGVfvpDataFS - Передача данных о ВФВП
     * @param vfvpMsgs          - Данные о ВФВП
     */
    void signalMSGVfvpDataFS(const QVector < QByteArray >& vfvpMsgs);
    void signalMSGVfvpDataUDP(const QVector < QByteArray >& vfvpMsgs);
    void signalMSGVfvpDataTCP(const QVector < QByteArray >& vfvpMsgs);

    ///Сигнал при выборке сообщения
    void inSignalOnDeleteMSG(const QString &payload);
    ///Сигнал при выборке сообщения (FS)
    void outSignalOnDeleteMSGFs(const QString &payload);
    ///Сигнал при выборке сообщения (UDP)
    void outSignalOnDeleteMSGUdp(const QString &payload);
    ///Сигнал при выборке сообщения (TCP)
    void outSignalOnDeleteMSGTcp(const QString &payload);

    ///Сигнал при выборке сообщения КСИ
    void inSignalOnDeleteMSGKsi(const QString &payload);
    ///Сигнал при выборке сообщения КСИ (FS)
   // void outSignalOnDeleteMSGFsKsi(const QString &payload);
    ///Сигнал при выборке сообщения КСИ (UDP)
 //   void outSignalOnDeleteMSGUdpKsi(const QString &payload);
    ///Сигнал при выборке сообщения КСИ (TCP)
 //   void outSignalOnDeleteMSGTcpKsi(const QString &payload);
    /// Сигнал о смене статуса подключения
    void statDbconnection(const bool asuv, const bool povz);
    void signalReconn();
    ///сигнал о поступившем сообщении (передаем в сигнале подтип сообщения)
    void postgresNotificationReceived(const QString &msgSubtype);
    ///сигнал о сообщении через файловую систему (передаем в сигнале подтип сообщения)
    void postgresNotificationReceivedFS(const QString &notificationName);
    ///сигнал о сообщении через UDP (передаем в сигнале подтип сообщения)
    void postgresNotificationReceivedUDP(const QString &notificationName);
    ///сигнал о сообщении через TCP (передаем в сигнале подтип сообщения)
    void postgresNotificationReceivedTCP(const QString &notificationName);
    ///сигнал о поступившем сообщении (передаем в сигнале подтип сообщения)
    void postgresNotificationReceivedKsi();
    ///сигнал о задержке сообщения
    void postgresNotificationReceivedDelayed();
    ///сигнал о сообщении через файловую систему (передаем в сигнале подтип сообщения)
  //  void postgresNotificationReceivedFSKsi(const QString &notificationName);
    ///сигнал о сообщении через UDP (передаем в сигнале подтип сообщения)
  //  void postgresNotificationReceivedUDPKsi(const QString &notificationName);
    ///сигнал о сообщении через TCP (передаем в сигнале подтип сообщения)
  //  void postgresNotificationReceivedTCPKsi(const QString &notificationName);
    void signalTLKNoti(const QString &notificationName, QSqlDriver::NotificationSource source, const QVariant &payload);
    void signalFSNoti(const QString &notificationName, QSqlDriver::NotificationSource source, const QVariant &payload);
    void signalUDPNoti(const QString &notificationName, QSqlDriver::NotificationSource source, const QVariant &payload);
    void signalTCPNoti(const QString &notificationName, QSqlDriver::NotificationSource source, const QVariant &payload);
    void signalTLKNotiKsi(const QString &notificationName, QSqlDriver::NotificationSource source, const QVariant &payload);
    void signalTLKNOTYnDelayed(const QString &notificationName, QSqlDriver::NotificationSource source);
    //void signalFSNotiKsi(const QString &notificationName, QSqlDriver::NotificationSource source, const QVariant &payload);
    //void signalUDPNotiKsi(const QString &notificationName, QSqlDriver::NotificationSource source, const QVariant &payload);
   // void signalTCPNotiKsi(const QString &notificationName, QSqlDriver::NotificationSource source, const QVariant &payload);
    /// Передаем подтип КСИ
    void signalNEWKsi(const QString &subTypeKsi);

public slots:    

    /// Перезапуск подключения к БД
    bool unsubscribeNotify();
    /**
     * @brief selectMsgVfsv - Получение данных по ВФСВ из БД
     */
    void selectMsgVfsv();
    /**
     * @brief selectMsgVfsvZip  -Получение данных по ВФСВ из БД для zip
     */
    void selectMsgVfsvZip();
    /**
     * @brief selectMsgVfvpZip  -Получение данных по ВФВП из БД для zip
     */
    void selectMsgVfvpZip();
    void selectMsgKsiZip();
    /**
     * @brief selectMsgKsi - Получение данных по КСИ из БД
     */
    void selectMsgKsi();
    /**
     * @brief selectMsgVfvp - Получение данных по ВФВП из БД
     */
    void selectMsgVfvp();
    /**
     * @brief selectMsgVfsvFS - Получение данных по ВФСВ из БД (FS)
     */
   // void selectMsgVfsvFS();
    /**
     * @brief selectMsgKsiFS - Получение данных по КСИ из БД (FS)
     */
   // void selectMsgFSKsi();
    /**
     * @brief selectMsgUDPKsi - Получение данных по КСИ из БД (UDP)
     */
   // void selectMsgUDPKsi();
    /**
     * @brief selectMsgTCPKsi - Получение данных по КСИ из БД (TCP)
     */
  //  void selectMsgTCPKsi();
    /**
     * @brief selectMsgVfvpFS - Получение данных по ВФВП из БД (FS)
     */
    void selectMsgVfvpFS();
    /**
     * @brief selectMsgVfsvUDP - Получение данных по ВФСВ из БД (UDP)
     */
   // void selectMsgVfsvUDP();
    /**
     * @brief selectMsgVfvpUDP - Получение данных по ВФВП из БД (UDP)
     */
    void selectMsgVfvpUDP();
    /**
     * @brief selectMsgVfsvUDP - Получение данных по ВФСВ из БД (UDP)
     */
   // void selectMsgVfsvTCP();
    /**
     * @brief selectMsgVfvpUDP - Получение данных по ВФВП из БД (UDP)
     */
    void selectMsgVfvpTCP();
    /**
     * @brief openDataBase - Инициируем подключение к базе данных
     * @param sqlParam     - параметры подключения к базе данных
     * @return             - статус подключения к базе данных
     */
    bool openDataBase(  const CSettings &sqlParam  );
    ///Получение сигнала и подтипа сообщения из PostgreSQL
    void handlePostgresNotification(const QString &notificationName, QSqlDriver::NotificationSource source, const QVariant &payload);
    ///Получение сигнала и подтипа сообщения из PostgreSQL (FS)
    void handlePostgresNotificationFS(const QString &notificationName, QSqlDriver::NotificationSource source, const QVariant &payload);
    ///Получение сигнала и подтипа сообщения из PostgreSQL (UDP)
    void handlePostgresNotificationUDP(const QString &notificationName, QSqlDriver::NotificationSource source, const QVariant &payload);
    ///Получение сигнала и подтипа сообщения из PostgreSQL (TCP)
    void handlePostgresNotificationTCP(const QString &notificationName, QSqlDriver::NotificationSource source, const QVariant &payload);
    /// Получение сигнала о задержке сообщения
    void handlePostgresNotificationDelayed(const QString &notificationName, QSqlDriver::NotificationSource source);

    //------------------------------------------------КСИ-----------------------------------------

    ///Получение сигнала и подтипа сообщения из PostgreSQL
    void handlePostgresNotificationKsi(const QString &notificationName, QSqlDriver::NotificationSource source, const QVariant &payload);
    ///Получение сигнала и подтипа сообщения из PostgreSQL (FS)
  //  void handlePostgresNotificationFSKsi(const QString &notificationName, QSqlDriver::NotificationSource source, const QVariant &payload);
    ///Получение сигнала и подтипа сообщения из PostgreSQL (UDP)
 //   void handlePostgresNotificationUDPKsi(const QString &notificationName, QSqlDriver::NotificationSource source, const QVariant &payload);
    ///Получение сигнала и подтипа сообщения из PostgreSQL (TCP)
  //  void handlePostgresNotificationTCPKsi(const QString &notificationName, QSqlDriver::NotificationSource source, const QVariant &payload);

    /// Получение данных из БД
    QVector < QByteArray > selectFromInMSG( const QString &msgSubtype );
    QVector < QByteArray > selectFromOutMSGFs( const QString &msgSubtype );
    QVector < QByteArray > selectFromOutMSGUdp( const QString &msgSubtype );
    QVector < QByteArray > selectFromOutMSGTcp( const QString &msgSubtype );

    /// Получение данных из БД для zip
    QVector < QByteArray > selectFromInMSGZip( const QString &msgSubtype );


    QString selectInMSG_ksi();
   // QString selectInMSG_ksiZip();

    QByteArray selectFromInMSGKSI( const QString &msgType );
    QByteArray selectFromInMSGKSIZip( const QString &msgType );

  //  QVector < QByteArray > selectFromOutMSGFsKSI( const QString &msgType );
   // QVector < QByteArray > selectFromOutMSGUdpKSI( const QString &msgType );
    //  QVector < QByteArray > selectFromOutMSGTcpKSI( const QString &msgType );
   // QByteArray selectFromOutMSGTcpKSI( const QString &msgType );

    /**
     * @brief checkFromInMSG - Проверка сообщений
     * @param msgSubtype     - подтип сообщений
     * @return               - статус проверки сообщений
     */
    int checkFromInMSG( const QString &msgSubtype );

    int checkFromOutMsgFS(const QString &msgSubtype );
    int checkFromOutMsgUDP( const QString &msgSubtype );
    int checkFromOutMsgTCP( const QString &msgSubtype );

    int checkFromInMSGKsi(const QString &msgType );
    int checkFromInMSGCountZip(const QString &msgType );


   // int checkFromOutMsgFSKsi(const QString &msgType );
   // int checkFromOutMsgUDPKsi(const QString &msgType );
   // int checkFromOutMsgTCPKsi(const QString &msgType );

    /**
     * @brief sendViaTlk - Отправка сообщений через tlk
     * @param msgUrgent  - категория срочности
     * @param msgMac     - мандатная метка
     * @param msgType    - тип сообщения
     * @param msgSubtype - подтип сообщения
     * @param msgTtl     - время жизни сообщения
     * @param msgAddrLst - адрес(а) получателя(ей) сообщения
     * @param msgData    - данные сообщения
     * @return           - статус отправки сообщений
     */
    bool sendViaTlk( const QString    &msgUrgent, const QString     &msgMac    ,
                    const QString    &msgType  , const QString     &msgSubtype,
                    const QString    &msgTtl   , const QStringList &msgAddrLst,
                    const QByteArray &msgData );
    bool sendViaTlkUDP(const QString    &msgUrgent, const QString     &msgMac    ,
                       const QString    &msgType  , const QString     &msgSubtype,
                       const QString    &msgTtl   , const QStringList &msgAddrLst,
                       const QString &msgUser, const QByteArray &msgData);
    bool sendViaTlkTCP(const QString    &msgUrgent, const QString     &msgMac    ,
                       const QString    &msgType  , const QString     &msgSubtype,
                       const QString    &msgTtl   , const QStringList &msgAddrLst,
                       const QString &msgUser, const QByteArray &msgData);

    void handleSocketActivated(int socket, QSocketNotifier::Type type);
    void handleDatabaseError(const QSqlError &error);
private slots:

    void NotificationS(const QString &notificationName, QSqlDriver::NotificationSource source, const QVariant &payload);
private:
         /// делаем переменную глобальной для сохранения возможности механизма отписки от уведомлений (хранит статус подписки)
    QSqlDriver *driver;

    void updateFromInMSG(const QStringList &idLst);
    void updateFromInMSGKsi(const QStringList &idLstKSIzip);
    /**
     * @brief deleteFromInMSG - Удаление обработанных сообщений
     * @param idLst           - список id обработанных сообщений
     */
    void deleteFromInMSG( const QStringList &idLst );
    void deleteFromOutMSGFs(const QStringList &idLstfs );
    void deleteFromOutMSGUdp(const QStringList &idLstudp );
    void deleteFromOutMSGTcp(const QStringList &idLsttcp );

    void deleteFromInMSGKsi(const QStringList &idLst );
   // void deleteFromOutMSGFsKsi(const QStringList &idLstfs );
   // void deleteFromOutMSGUdpKsi(const QStringList &idLstudp );
   // void deleteFromOutMSGTcpKsi(const QStringList &idLsttcp );


    /**
     * @brief initKlassTableMap - Задаем коллекцию таблиц классификаторов
     */
    void initKlassTableMap();


};

#endif // CSQLDATABASE_H
