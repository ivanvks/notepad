#include "csqldatabase.h"

#include <QDebug>
#include <QUuid>
#include <QThread>
#include <QCoreApplication>
#include <QSqlQueryModel>
#include <QTimer>
#include <QMessageBox>
#include <QProcess>
#include <libpq-fe.h>

//bool CSqlDatabase::eventFilter(QObject *watched, QEvent *event)
//{
//    if (watched == m_socketNotifier && event->type() == QEvent::SockClose) {
//        qDebug() << "Перехвачено событие SocketError";
//        // Обработка события SocketError
//        return true; // Указываем, что событие обработано
//    }
//    return QObject::eventFilter(watched, event);
//}

CSqlDatabase::CSqlDatabase( const QString &type )
{
    /// инициализируем объект для работы с базой данных ASUV
    //mASUVDataBase_ = QSqlDatabase::addDatabase( type, "asuv" );
    /// инициализируем объект для работы с базой данных POVZ
   // mPOVZDataBase_ = QSqlDatabase::addDatabase( type, "povz" );
    /// задаем коллекцию таблиц классификаторов
    initKlassTableMap();
        /// Подключаем сигнал от базы данных о входящем сообщении  к слоту обработки уведомлений
    QObject::connect(this, SIGNAL(signalTLKNoti(QString, QSqlDriver::NotificationSource, QVariant)),
                     this, SLOT(handlePostgresNotification(QString, QSqlDriver::NotificationSource, QVariant)));
    /// Подключаем сигнал от базы данных о входящем сообщении  к слоту обработки уведомлений
    QObject::connect(this, SIGNAL(signalFSNoti(QString, QSqlDriver::NotificationSource, QVariant)),
                     this, SLOT(handlePostgresNotificationFS(QString, QSqlDriver::NotificationSource, QVariant)));
    /// Подключаем сигнал от базы данных о входящем сообщении  к слоту обработки уведомлений
    QObject::connect(this, SIGNAL(signalUDPNoti(QString, QSqlDriver::NotificationSource, QVariant)),
                     this, SLOT(handlePostgresNotificationUDP(QString, QSqlDriver::NotificationSource, QVariant)));
    /// Подключаем сигнал от базы данных о входящем сообщении  к слоту обработки уведомлений
    QObject::connect(this, SIGNAL(signalTCPNoti(QString, QSqlDriver::NotificationSource, QVariant)),
                     this, SLOT(handlePostgresNotificationTCP(QString, QSqlDriver::NotificationSource, QVariant)));
    /// Подключаем сигнал от базы данных о входящем сообщении  к слоту обработки уведомлений
    QObject::connect(this, SIGNAL(signalTLKNotiKsi(QString, QSqlDriver::NotificationSource, QVariant)),
                     this, SLOT(handlePostgresNotificationKsi(QString, QSqlDriver::NotificationSource, QVariant)));
    /// Подключаем сигнал от базы данных о задержке сообщения к слоту обработки уведомлений
    QObject::connect(this, SIGNAL(signalTLKNOTYnDelayed(QString, QSqlDriver::NotificationSource)),
                     this, SLOT(handlePostgresNotificationDelayed(QString, QSqlDriver::NotificationSource)));

    /// Подключаем сигнал от базы данных о входящем сообщении  к слоту обработки уведомлений
  //  QObject::connect(this, SIGNAL(signalFSNotiKsi(QString, QSqlDriver::NotificationSource, QVariant)),
                   //  this, SLOT(handlePostgresNotificationFSKsi(QString, QSqlDriver::NotificationSource, QVariant)));
    /// Подключаем сигнал от базы данных о входящем сообщении  к слоту обработки уведомлений
  // QObject::connect(this, SIGNAL(signalUDPNotiKsi(QString, QSqlDriver::NotificationSource, QVariant)),
                    // this, SLOT(handlePostgresNotificationUDPKsi(QString, QSqlDriver::NotificationSource, QVariant)));
    /// Подключаем сигнал от базы данных о входящем сообщении  к слоту обработки уведомлений
  //  QObject::connect(this, SIGNAL(signalTCPNotiKsi(QString, QSqlDriver::NotificationSource, QVariant)),
                    // this, SLOT(handlePostgresNotificationTCPKsi(QString, QSqlDriver::NotificationSource, QVariant)));
//    int socketDescriptor = mASUVDataBase_.driver()->handle().toInt();
//    m_socketNotifier = new QSocketNotifier(socketDescriptor, QSocketNotifier::Exception, this);
//    connect(m_socketNotifier, &QSocketNotifier::activated, this, &CSqlDatabase::handleSocketActivated);

    // Установка фильтра событий для MyClass
    this->installEventFilter(this);
}
/// Перезапуск подключения к БД
bool CSqlDatabase::unsubscribeNotify()
{   /// проверяем в каком сейчас находимся потоке
    qDebug() << __PRETTY_FUNCTION__<<"unsubscribeNotify --Start" <<QThread::currentThread();
    ///Выполняем отписку от уведомлений PostgreSQL
    if (driver->unsubscribeFromNotification("message_updated")) {
        qDebug() << "Отписка от уведомлений PostgreSQL 'message_updated' выполнена успешно";
    } else {
        qDebug() << "Не удалось отписаться от уведомлений PostgreSQL 'message_updated'";
    }
    if (driver->unsubscribeFromNotification("message_updated_fs")) {
        qDebug() << "Отписка от уведомлений PostgreSQL 'message_updated_fs' выполнена успешно";
    } else {
        qDebug() << "Не удалось отписаться от уведомлений PostgreSQL 'message_updated_fs'";
    }
    if (driver->unsubscribeFromNotification("message_updated_udp")) {
        qDebug() << "Отписка от уведомлений PostgreSQL 'message_updated_udp' выполнена успешно";
    } else {
        qDebug() << "Не удалось отписаться от уведомлений PostgreSQL 'message_updated_udp'";
    }
    if (driver->unsubscribeFromNotification("message_updated_tcp")) {
        qDebug() << "Отписка от уведомлений PostgreSQL 'message_updated_tcp' выполнена успешно";
    } else {
        qDebug() << "Не удалось отписаться от уведомлений PostgreSQL 'message_updated_tcp'";
    }
    if (driver->unsubscribeFromNotification("n_delayed")) {
        qDebug() << "Отписка от уведомлений PostgreSQL 'n_delayed' выполнена успешно";
    } else {
        qDebug() << "Не удалось отписаться от уведомлений PostgreSQL 'n_delayed'";
    }
    ///Закрываем подключение к базам данных
    mASUVDataBase_.close();
    mPOVZDataBase_.close();
    mASUVDataBase_ = QSqlDatabase();
    mPOVZDataBase_ = QSqlDatabase();
    if (QSqlDatabase::contains("asuv")){
        QSqlDatabase::removeDatabase("asuv");
    }
    if (QSqlDatabase::contains("povz")){
        QSqlDatabase::removeDatabase("povz");
    }

    /// конец выполнения метода
    qDebug() << __PRETTY_FUNCTION__<<"unsubscribeNotify  --End" <<QThread::currentThread();
    return true;
}
/// Инициируем подключение к базе данных
bool CSqlDatabase::openDataBase( const CSettings &sqlParam )
{
    qDebug() << "openDataBase" ;
    /// Проверяем  в каких потоках выполяются подключение к БД и App
    qDebug()<<QThread::currentThread()<<qApp->thread();
    /// Инициализируем объект для работы с базой данных ASUV
    mASUVDataBase_ = QSqlDatabase::addDatabase( "QPSQL", "asuv" );
    /// Инициализируем объект для работы с базой данных POVZ
    mPOVZDataBase_ = QSqlDatabase::addDatabase( "QPSQL", "povz" );
    /// задаем хост базы данных ASUV
    mASUVDataBase_.setHostName    ( sqlParam.asuvParam().value( "host" )         );
    /// задаем порт базы данных ASUV
    mASUVDataBase_.setPort        ( sqlParam.asuvParam().value( "port" ).toInt() );
    /// задаем имя базы данных ASUV
    mASUVDataBase_.setDatabaseName( sqlParam.asuvParam().value( "name" )         );
    /// задаем имя пользователя ASUV
    mASUVDataBase_.setUserName    ( sqlParam.asuvParam().value( "user" )         );
    /// задаем пароль пользователя ASUV
    mASUVDataBase_.setPassword    ( sqlParam.asuvParam().value( "pass" )         );
    /// подключение к базе данных ASUV
    qDebug() << "\n"; qDebug() <<  __PRETTY_FUNCTION__ << "[CHECK DATABASE ACCESS] =>"
             << QString( "%1:%2 [%3]" ).arg( mASUVDataBase_.hostName(),
                                          QString::number( mASUVDataBase_.port() ),
                                          mASUVDataBase_.databaseName() );
    if ( !mASUVDataBase_.open() ) {
        qDebug() << __PRETTY_FUNCTION__ << "[ACCESS DENIED]";
        qDebug() << __PRETTY_FUNCTION__ << mASUVDataBase_.lastError();
    } else {
        qDebug() << __PRETTY_FUNCTION__ << "[ACCESS ACCEPTED]";
    }
    /// Проверяем поддерживает ли драйвер базы данных механизм оповещений (EventNotifications)
    driver = mASUVDataBase_.driver();
    if (driver->hasFeature(QSqlDriver::EventNotifications)) {
        /// Подписываемся на уведомления PostgreSQL
        if (driver->subscribeToNotification("message_updated")) {
            qDebug() << "Подписка на уведомление PostgreSQL 'message_updated' выполнена успешно";

        } else {
            qDebug() << "Не удалось подписаться на уведомление PostgreSQL 'message_updated'";
        }
        if (driver->subscribeToNotification("message_updated_fs")) {
            qDebug() << "Подписка на уведомление PostgreSQL 'message_updated_fs' выполнена успешно";

        } else {
            qDebug() << "Не удалось подписаться на уведомление PostgreSQL 'message_updated_fs'";
        }
        if (driver->subscribeToNotification("message_updated_udp")) {
            qDebug() << "Подписка на уведомление PostgreSQL 'message_updated_udp' выполнена успешно";

        } else {
            qDebug() << "Не удалось подписаться на уведомление PostgreSQL 'message_updated_udp'";
        }
        if (driver->subscribeToNotification("message_updated_tcp")) {
            qDebug() << "Подписка на уведомление PostgreSQL 'message_updated_tcp' выполнена успешно";

        } else {
            qDebug() << "Не удалось подписаться на уведомление PostgreSQL 'message_updated_tcp'";
        }
        if (driver->subscribeToNotification("message_updated_ksi")) {
            qDebug() << "Подписка на уведомление PostgreSQL 'message_updated_ksi' выполнена успешно";

        } else {
            qDebug() << "Не удалось подписаться на уведомление PostgreSQL 'message_updated_ksi'";
        }if (driver->subscribeToNotification("n_delayed")) {
            qDebug() << "Подписка на уведомление PostgreSQL 'n_delayed' выполнена успешно";

        } else {
            qDebug() << "Не удалось подписаться на уведомление PostgreSQL 'n_delayed'";
        }
//        if (driver->subscribeToNotification("message_updated_fs_ksi")) {
//            qDebug() << "Подписка на уведомление PostgreSQL 'message_updated_fs_ksi' выполнена успешно";

//        } else {
//            qDebug() << "Не удалось подписаться на уведомление PostgreSQL 'message_updated_fs'";
//        }
//        if (driver->subscribeToNotification("message_updated_udp_ksi")) {
//            qDebug() << "Подписка на уведомление PostgreSQL 'message_updated_udp_ksi' выполнена успешно";

//        } else {
//            qDebug() << "Не удалось подписаться на уведомление PostgreSQL 'message_updated_udp'";
//        }
//        if (driver->subscribeToNotification("message_updated_tcp_ksi")) {
//            qDebug() << "Подписка на уведомление PostgreSQL 'message_updated_tcp_ksi' выполнена успешно";

//        } else {
//            qDebug() << "Не удалось подписаться на уведомление PostgreSQL 'message_updated_tcp'";
//        }
    } else {
        qDebug() << "Драйвер PostgreSQL не поддерживает уведомления";
    }

    /// Подключаем сигнал от базы данных о входящем сообщении  к слоту обработки уведомлений
    QObject::connect(mASUVDataBase_.driver(),
                     SIGNAL(notification(QString, QSqlDriver::NotificationSource, QVariant)),
                     this, SLOT(NotificationS(QString, QSqlDriver::NotificationSource, QVariant)));

    /// задаем хост базы данных POVZ
    mPOVZDataBase_.setHostName    ( sqlParam.povzParam().value( "host" )         );
    /// задаем порт базы данных POVZ
    mPOVZDataBase_.setPort        ( sqlParam.povzParam().value( "port" ).toInt() );
    /// задаем имя базы данных POVZ
    mPOVZDataBase_.setDatabaseName( sqlParam.povzParam().value( "name" )         );
    /// задаем имя пользователя POVZ
    mPOVZDataBase_.setUserName    ( sqlParam.povzParam().value( "user" )         );
    /// задаем пароль пользователя POVZ
    mPOVZDataBase_.setPassword    ( sqlParam.povzParam().value( "pass" )         );
    /// подключение к базе данных POVZ
    qDebug() << "\n"; qDebug() <<  __PRETTY_FUNCTION__ << "[CHECK DATABASE ACCESS] =>"
             << QString( "%1:%2 [%3]" ).arg( mPOVZDataBase_.hostName(),
                                          QString::number( mPOVZDataBase_.port() ),
                                          mPOVZDataBase_.databaseName() );
    if ( !mPOVZDataBase_.open() ) {
        qDebug() << __PRETTY_FUNCTION__ << "[ACCESS DENIED]";
        qDebug() << __PRETTY_FUNCTION__ << mPOVZDataBase_.lastError();
    } else {
        qDebug() << __PRETTY_FUNCTION__ << "[ACCESS ACCEPTED]";
    }

    // Подключение к базе данных
    conn = PQconnectdb("hostaddr=127.0.0.1 port=5432 dbname=skill user=skill password=12345");

    // Получение дескриптора сокета
    int socketDescriptor = PQsocket(conn);

    // Использование дескриптора сокета, например:
    if (socketDescriptor >= 0) {
        // Сокет действителен, делайте что-то с ним
    } else {
        // Произошла ошибка
    }

    // Закрытие соединения
   // PQfinish(conn);





    // Создаем QSocketNotifier для мониторинга событий сокета
    //int socketDescriptor = mASUVDataBase_.driver()->handle().toInt();
    //int socketDescriptor = mASUVDataBase_.driver()->socketDescriptor();
      QSocketNotifier *notifier = new QSocketNotifier(socketDescriptor, QSocketNotifier::Read, this);
       connect(notifier, &QSocketNotifier::activated, this, &CSqlDatabase::handleSocketActivated);
    //!QSocketNotifier::isEnabled();
//    QSocketNotifier::eventFilter(dd, ff);
    qDebug() <<"FHF--GHJTF------VMFV bszdf io;hs" << socketDescriptor ;
//QObject::connect(&mASUVDataBase_, SIGNAL(error(QSqlError)), this, SLOT(handleDatabaseError(QSqlError)));
    emit statDbconnection(mASUVDataBase_.isOpen(), mPOVZDataBase_.isOpen());
    /// Сигнализируем о завершении работы метода
    qDebug() << __PRETTY_FUNCTION__<<"End" <<QThread::currentThread();
    /// Возвращаем статус подключения к БД
    return mASUVDataBase_.isOpen() && mPOVZDataBase_.isOpen();
}
// Реализация слота для обработки события разрыва соединения
void CSqlDatabase::handleSocketActivated(int socket, QSocketNotifier::Type type) {
    // Q_UNUSED(socket);
  qDebug() <<"F!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!.--------- bszdf io;hs" << socket;
//  if (type == QSocketNotifier::Read && socket == -1) {
//        // if (type == QSocketNotifier::Read) {
//        // Здесь можно выполнить действия по обработке разрыва соединения
//        qDebug() << "Соединение с базой данных разорвано";
//        // Или выполнить какие-то другие действия, например, показать сообщение оператору
//    }
  PQfinish(conn);
//emit statDbconnection(false, false);
  emit signalReconn();

}
// Реализация слота для обработки ошибок
    void CSqlDatabase::handleDatabaseError(const QSqlError &error) {
    // Здесь вы можете выполнить действия по обработке ошибки, например, показать диалоговое окно с сообщением об ошибке оператору
    qDebug() << "Database error occurred:" << error.text();
    // Или можно использовать QMessageBox для отображения сообщения в графическом интерфейсе
    QMessageBox::critical(nullptr, "Database Error", error.text());
}

/// Возвращаем статус подключения к ASUV
bool CSqlDatabase::isOpenASUV()
{
    return mASUVDataBase_.isOpen();
}

/// Возвращаем статус подключения к POVZ
bool CSqlDatabase::isOpenPOVZ()
{
    return mPOVZDataBase_.isOpen();
}

/// Возвращаем информацию о последней ошибке, произошедшей в базе данных ASUV
QString CSqlDatabase::lastErrorASUV()
{
    return mASUVDataBase_.lastError().text();
}

/// Возвращаем информацию о последней ошибке, произошедшей в базе данных POVZ
QString CSqlDatabase::lastErrorPOVZ()
{
    return mPOVZDataBase_.lastError().text();
}

/// Проверка сообщений
int CSqlDatabase::checkFromInMSG(const QString &msgSubtype)
{
    qDebug() << "Запустилась проверка поступивших в базу данных сообщений по подтипу:" << msgSubtype ;
    /// инициализируем запрос к базе данных
    QSqlQuery sqlQuery( mASUVDataBase_ );
    /// задаем запрос к базе данных
    sqlQuery.prepare( "SELECT count(msg_id) FROM "
                     "in_msg_buff "
                     "WHERE msg_subtype = :msgSubtype");
    /// задаем подтип сообщения
    sqlQuery.bindValue( ":msgSubtype", msgSubtype );
    /// выполняем запрос к базе данных
    if( !sqlQuery.exec() ) {
        qDebug() << __PRETTY_FUNCTION__ << sqlQuery.lastQuery() << sqlQuery.lastError();
        /// возвращаем статус проверки сообщений
        return 0;
    }
    /// получаем статус проверки сообщений
    if( !sqlQuery.first() ) {
        /// возвращаем статус проверки сообщений
        return 0;
    }
    /// возвращаем статус проверки сообщений
    return sqlQuery.value( 0 ).toInt();
}
int CSqlDatabase::checkFromInMSGKsi(const QString &msgType)
{
    qDebug() << "Запустилась проверка поступивших в базу данных сообщений по типу:" << msgType ;
    /// инициализируем запрос к базе данных
    QSqlQuery sqlQuery( mASUVDataBase_ );///////////////////////////////////////////////////
    /// задаем запрос к базе данных
    sqlQuery.prepare( "SELECT count(msg_id) FROM "
                     "in_msg_buff "
                     "WHERE msg_type = :msgType");
    /// задаем подтип сообщения
    sqlQuery.bindValue( ":msgType", msgType );
    /// выполняем запрос к базе данных
    if( !sqlQuery.exec() ) {
        qDebug() << __PRETTY_FUNCTION__ << sqlQuery.lastQuery() << sqlQuery.lastError();
        /// возвращаем статус проверки сообщений
        return 0;
    }
    /// получаем статус проверки сообщений
    if( !sqlQuery.first() ) {
        /// возвращаем статус проверки сообщений
        return 0;
    }
    /// возвращаем статус проверки сообщений
    return sqlQuery.value( 0 ).toInt();
}

int CSqlDatabase::checkFromInMSGCountZip(const QString &msgType)
{
    qDebug() << "Запустилась проверка не прочитанных сообщений по типу:" << msgType ;
    /// инициализируем запрос к базе данных
    QSqlQuery sqlQuery( mASUVDataBase_ );///////////////////////////////////////////////////
    /// задаем запрос к базе данных
    sqlQuery.prepare( "SELECT count(msg_id) FROM "
                     "in_msg_buff "
                     "WHERE msg_type = :msgType AND msg_zip = FALSE ");
    /// задаем подтип сообщения
    sqlQuery.bindValue( ":msgType", msgType );
    /// выполняем запрос к базе данных
    if( !sqlQuery.exec() ) {
        qDebug() << __PRETTY_FUNCTION__ << sqlQuery.lastQuery() << sqlQuery.lastError();
        /// возвращаем статус проверки сообщений
        return 0;
    }
    /// получаем статус проверки сообщений
    if( !sqlQuery.first() ) {
        /// возвращаем статус проверки сообщений
        return 0;
    }
    /// возвращаем статус проверки сообщений
    return sqlQuery.value( 0 ).toInt();
}
int CSqlDatabase::checkFromOutMsgFS(const QString &msgSubtype)
{
    qDebug() << "Запустилась проверка поступивших в базу данных сообщений по подтипу:" << msgSubtype ;
    /// инициализируем запрос к базе данных
    QSqlQuery sqlQuery( mASUVDataBase_ );
    /// задаем запрос к базе данных
    sqlQuery.prepare( "SELECT count(msg_id) FROM "
                     "out_msg_buff_fs "
                     "WHERE msg_Subtype = :msgSubtype");
    /// задаем подтип сообщения
    sqlQuery.bindValue( ":msgSubtype", msgSubtype );
    /// выполняем запрос к базе данных
    if( !sqlQuery.exec() ) {
        qDebug() << __PRETTY_FUNCTION__ << sqlQuery.lastQuery() << sqlQuery.lastError();
        /// возвращаем статус проверки сообщений
        return 0;
    }
    /// получаем статус проверки сообщений
    if( !sqlQuery.first() ) {
        /// возвращаем статус проверки сообщений
        return 0;
    }
    /// возвращаем статус проверки сообщений
    return sqlQuery.value( 0 ).toInt();
}
//int CSqlDatabase::checkFromOutMsgFSKsi(const QString &msgType)
//{
//    qDebug() << "Запустилась проверка поступивших в базу данных сообщений по подтипу:" << msgType ;
//    /// инициализируем запрос к базе данных
//    QSqlQuery sqlQuery( mASUVDataBase_ );///////////////////////////////////////////////////
//    /// задаем запрос к базе данных
//    sqlQuery.prepare( "SELECT count(msg_id) FROM "
//                     "out_msg_buff_fs "
//                     "WHERE msg_type = :msgType");
//    /// задаем подтип сообщения
//    sqlQuery.bindValue( ":msgType", msgType );
//    /// выполняем запрос к базе данных
//    if( !sqlQuery.exec() ) {
//        qDebug() << __PRETTY_FUNCTION__ << sqlQuery.lastQuery() << sqlQuery.lastError();
//        /// возвращаем статус проверки сообщений
//        return 0;
//    }
//    /// получаем статус проверки сообщений
//    if( !sqlQuery.first() ) {
//        /// возвращаем статус проверки сообщений
//        return 0;
//    }
//    /// возвращаем статус проверки сообщений
//    return sqlQuery.value( 0 ).toInt();
//}
int CSqlDatabase::checkFromOutMsgUDP(const QString &msgSubtype)
{
    qDebug() << "Запустилась проверка поступивших в базу данных сообщений по подтипу:" << msgSubtype ;
    /// инициализируем запрос к базе данных
    QSqlQuery sqlQuery( mASUVDataBase_ );
    /// задаем запрос к базе данных
    sqlQuery.prepare( "SELECT count(msg_id) FROM "
                     "out_msg_buff_udp "
                     "WHERE msg_subtype = :msgSubtype");
    /// задаем подтип сообщения
    sqlQuery.bindValue( ":msgSubtype", msgSubtype );
    /// выполняем запрос к базе данных
    if( !sqlQuery.exec() ) {
        qDebug() << __PRETTY_FUNCTION__ << sqlQuery.lastQuery() << sqlQuery.lastError();
        /// возвращаем статус проверки сообщений
        return 0;
    }
    /// получаем статус проверки сообщений
    if( !sqlQuery.first() ) {
        /// возвращаем статус проверки сообщений
        return 0;
    }
    /// возвращаем статус проверки сообщений
    return sqlQuery.value( 0 ).toInt();
}
//int CSqlDatabase::checkFromOutMsgUDPKsi(const QString &msgType)
//{
//    qDebug() << "Запустилась проверка поступивших в базу данных сообщений по подтипу:" << msgType ;
//    /// инициализируем запрос к базе данных
//    QSqlQuery sqlQuery( mASUVDataBase_ );///////////////////////////////////////////////////
//    /// задаем запрос к базе данных
//    sqlQuery.prepare( "SELECT count(msg_id) FROM "
//                     "out_msg_buff_udp "
//                     "WHERE msg_type = :msgType");
//    /// задаем подтип сообщения
//    sqlQuery.bindValue( ":msgType", msgType );
//    /// выполняем запрос к базе данных
//    if( !sqlQuery.exec() ) {
//        qDebug() << __PRETTY_FUNCTION__ << sqlQuery.lastQuery() << sqlQuery.lastError();
//        /// возвращаем статус проверки сообщений
//        return 0;
//    }
//    /// получаем статус проверки сообщений
//    if( !sqlQuery.first() ) {
//        /// возвращаем статус проверки сообщений
//        return 0;
//    }
//    /// возвращаем статус проверки сообщений
//    return sqlQuery.value( 0 ).toInt();
//}
int CSqlDatabase::checkFromOutMsgTCP(const QString &msgSubtype)
{
    qDebug() << "Запустилась проверка поступивших в базу данных сообщений по подтипу:" << msgSubtype ;
    /// инициализируем запрос к базе данных
    QSqlQuery sqlQuery( mASUVDataBase_ );
    /// задаем запрос к базе данных
    sqlQuery.prepare( "SELECT count(msg_id) FROM "
                     "out_msg_buff_tcp "
                     "WHERE msg_subtype = :msgSubtype");
    /// задаем подтип сообщения
    sqlQuery.bindValue( ":msgSubtype", msgSubtype );
    /// выполняем запрос к базе данных
    if( !sqlQuery.exec() ) {
        qDebug() << __PRETTY_FUNCTION__ << sqlQuery.lastQuery() << sqlQuery.lastError();
        /// возвращаем статус проверки сообщений
        return 0;
    }
    /// получаем статус проверки сообщений
    if( !sqlQuery.first() ) {
        /// возвращаем статус проверки сообщений
        return 0;
    }
    /// возвращаем статус проверки сообщений
    return sqlQuery.value( 0 ).toInt();
}
//int CSqlDatabase::checkFromOutMsgTCPKsi(const QString &msgType)
//{
//    qDebug() << "Запустилась проверка поступивших в базу данных сообщений по подтипу:" << msgType ;
//    /// инициализируем запрос к базе данных
//    QSqlQuery sqlQuery( mASUVDataBase_ );///////////////////////////////////////////////////
//    /// задаем запрос к базе данных
//    sqlQuery.prepare( "SELECT count(msg_id) FROM "
//                     "out_msg_buff_tcp "
//                     "WHERE msg_type = :msgType");
//    /// задаем подтип сообщения
//    sqlQuery.bindValue( ":msgType", msgType );
//    /// выполняем запрос к базе данных
//    if( !sqlQuery.exec() ) {
//        qDebug() << __PRETTY_FUNCTION__ << sqlQuery.lastQuery() << sqlQuery.lastError();
//        /// возвращаем статус проверки сообщений
//        return 0;
//    }
//    /// получаем статус проверки сообщений
//    if( !sqlQuery.first() ) {
//        /// возвращаем статус проверки сообщений
//        return 0;
//    }
//    /// возвращаем статус проверки сообщений
//    return sqlQuery.value( 0 ).toInt();
//}
void CSqlDatabase::NotificationS(const QString &notificationName, QSqlDriver::NotificationSource source, const QVariant &payload)
{
    if (notificationName == QString("message_updated")){
        emit signalTLKNoti(notificationName, source, payload);
    }
    else if (notificationName == QString("message_updated_fs")){
        emit signalFSNoti(notificationName, source, payload);
    }
    else if (notificationName == QString("message_updated_udp")){
        emit signalUDPNoti(notificationName, source, payload);
    }
    else if (notificationName == QString("message_updated_tcp")){
        emit signalTCPNoti(notificationName, source, payload);
    }
    else if (notificationName == QString("message_updated_ksi")){
        emit signalTLKNotiKsi(notificationName, source, payload);
    }
    else if (notificationName == QString("n_delayed")){
        emit signalTLKNOTYnDelayed(notificationName, source);
    }
//    else if (notificationName == QString("message_updated_fs_ksi")){
//        emit signalFSNotiKsi(notificationName, source, payload);
//    }
//    else if (notificationName == QString("message_updated_udp_ksi")){
//        emit signalUDPNotiKsi(notificationName, source, payload);
//    }
//    else if (notificationName == QString("message_updated_tcp_ksi")){
//        emit signalTCPNotiKsi(notificationName, source, payload);
//    }

}
///Получение сигнала и подтипа сообщения из PostgreSQL
void CSqlDatabase::handlePostgresNotification(const QString &notificationName, QSqlDriver::NotificationSource source, const QVariant &payload)
{
    qDebug() << "Поступило новое уведомление PostgreSQL от канала:" << notificationName <<source;
    msgSubtypeTLK = payload.toString();
    qDebug() <<  "Подтип сообщения = " << msgSubtypeTLK << (msgSubtypeTLK == "514949" ? "Свои войска" : ( msgSubtypeTLK == "515249" ? "Войска противника" : "Другой подтип"));
    ///сигнал о поступившем сообщении (передаем в сигнале подтип сообщения)
    emit postgresNotificationReceived(msgSubtypeTLK);
}
void CSqlDatabase::handlePostgresNotificationFS(const QString &notificationName, QSqlDriver::NotificationSource source, const QVariant &payload)
{
    qDebug() << "Поступило новое уведомление PostgreSQL(FS) от канала:" << notificationName <<source;
    QString msgSubtype = payload.toString();
    qDebug() <<  "Подтип сообщения = " << msgSubtype << (msgSubtype == "514949" ? "Свои войска" : ( msgSubtype == "515249" ? "Войска противника" : "Другой подтип"));
    ///сигнал о поступившем сообщении (передаем в сигнале подтип сообщения)
    emit postgresNotificationReceivedFS(msgSubtype);
}
void CSqlDatabase::handlePostgresNotificationUDP(const QString &notificationName, QSqlDriver::NotificationSource source, const QVariant &payload)
{
    qDebug() << "Поступило новое уведомление PostgreSQL(UDP) от канала:" << notificationName <<source;
    QString msgSubtype = payload.toString();
    qDebug() <<  "Подтип сообщения = " << msgSubtype << (msgSubtype == "514949" ? "Свои войска" : ( msgSubtype == "515249" ? "Войска противника" : "Другой подтип"));
    ///сигнал о поступившем сообщении (передаем в сигнале подтип сообщения)
    emit postgresNotificationReceivedUDP(msgSubtype);
}
void CSqlDatabase::handlePostgresNotificationTCP(const QString &notificationName, QSqlDriver::NotificationSource source, const QVariant &payload)
{
    qDebug() << "Поступило новое уведомление PostgreSQL(TCP) от канала:" << notificationName <<source;
    QString msgSubtype = payload.toString();
    qDebug() <<  "Подтип сообщения = " << msgSubtype << (msgSubtype == "514949" ? "Свои войска" : ( msgSubtype == "515249" ? "Войска противника" : "Другой подтип"));
    ///сигнал о поступившем сообщении (передаем в сигнале подтип сообщения)
    emit postgresNotificationReceivedTCP(msgSubtype);
}
///Получение сигнала и подтипа сообщения из PostgreSQL
void CSqlDatabase::handlePostgresNotificationKsi(const QString &notificationName, QSqlDriver::NotificationSource source, const QVariant &payload)
{
    qDebug() << "Поступило новое уведомление PostgreSQL от канала:" << notificationName <<source;
    QString msgType = payload.toString();

    qDebug() <<  "Тип сообщения = " << msgType << (msgType == "26" ? "ОТИ" : ( msgType == "27" ? "КСИ" : "Другой тип"));
    ///сигнал о поступившем сообщении (передаем в сигнале подтип сообщения)
    if (msgType == "27" ) emit postgresNotificationReceivedKsi();
}
///Получение сигнала о задержке сообщения из PostgreSQL
void CSqlDatabase::handlePostgresNotificationDelayed(const QString &notificationName, QSqlDriver::NotificationSource source)
{
    qDebug() << "Поступило новое уведомление PostgreSQL от канала:" << notificationName <<source ;
    ///сигнал о задержке сообщения
    emit postgresNotificationReceivedDelayed();
}
//void CSqlDatabase::handlePostgresNotificationFSKsi(const QString &notificationName, QSqlDriver::NotificationSource source, const QVariant &payload)
//{
//    qDebug() << "Поступило новое уведомление PostgreSQL(FS) от канала:" << notificationName;
//    QString msgType = payload.toString();
//    //qDebug() <<  "Подтип сообщения = " << msgSubtype << (msgSubtype == "514949" ? "Свои войска" : ( msgSubtype == "515249" ? "Войска противника" : "Другой подтип"));
//    qDebug() <<  "Тип сообщения = " << msgType << (msgType == "26" ? "ОТИ" : ( msgType == "27" ? "КСИ" : "Другой тип"));
//    ///сигнал о поступившем сообщении (передаем в сигнале подтип сообщения)
//    if (msgType == "27" ) emit postgresNotificationReceivedFSKsi(msgType);
//}
//void CSqlDatabase::handlePostgresNotificationUDPKsi(const QString &notificationName, QSqlDriver::NotificationSource source, const QVariant &payload)
//{
//    qDebug() << "Поступило новое уведомление PostgreSQL(UDP) от канала:" << notificationName;
//    QString msgType = payload.toString();
//    //qDebug() <<  "Подтип сообщения = " << msgSubtype << (msgSubtype == "514949" ? "Свои войска" : ( msgSubtype == "515249" ? "Войска противника" : "Другой подтип"));
//    qDebug() <<  "Тип сообщения = " << msgType << (msgType == "26" ? "ОТИ" : ( msgType == "27" ? "КСИ" : "Другой тип"));
//    ///сигнал о поступившем сообщении (передаем в сигнале подтип сообщения)
//    if (msgType == "27" ) emit postgresNotificationReceivedUDPKsi(msgType);
//}
//void CSqlDatabase::handlePostgresNotificationTCPKsi(const QString &notificationName, QSqlDriver::NotificationSource source, const QVariant &payload)
//{
//    qDebug() << "Поступило новое уведомление PostgreSQL(TCP) от канала:" << notificationName;
//    QString msgType = payload.toString();
//    //qDebug() <<  "Подтип сообщения = " << msgSubtype << (msgSubtype == "514949" ? "Свои войска" : ( msgSubtype == "515249" ? "Войска противника" : "Другой подтип"));
//    qDebug() <<  "Тип сообщения = " << msgType << (msgType == "26" ? "ОТИ" : ( msgType == "27" ? "КСИ" : "Другой тип"));
//    ///сигнал о поступившем сообщении (передаем в сигнале подтип сообщения)
//    if (msgType == "27" ) emit postgresNotificationReceivedTCPKsi(msgType);
//}
/// Запрос сообщений ВФСВ
void CSqlDatabase::selectMsgVfsv()
{
    qDebug() << __PRETTY_FUNCTION__;
    /// Запускаем выборку сообщения из БД в поток подключения к БД
    /// Проверяем перенаправление в поток БД
    qDebug() << __PRETTY_FUNCTION__<<"Start" <<QThread::currentThread();
    /// Инициализируем коллекцию сообщений ВФСВ ТВФ ( запрашиваем из БД ( Tlk ) )
    QVector < QByteArray > vfsvMsgs( selectFromInMSG ( "514949" ) );
    /// Выводим коллекцию сообщений ВФСВ ТВФ
    qDebug() << __PRETTY_FUNCTION__ << "[TVF VFSV MSGS] =>" << vfsvMsgs;
    /// Посылаем данные из потока БД в поток gui для заполнения форм
    emit signalMSGVfsvData(vfsvMsgs);
    /// Сигнализируем о завершении работы метода
    qDebug() << __PRETTY_FUNCTION__<<"End" <<QThread::currentThread();

}

/// Запрос сообщений ВФСВ для zip
void CSqlDatabase::selectMsgVfsvZip()
{
    qDebug() << __PRETTY_FUNCTION__;
    /// Запускаем выборку сообщения из БД в поток подключения к БД
    /// Проверяем перенаправление в поток БД
    qDebug() << __PRETTY_FUNCTION__<<"StartZIP" <<QThread::currentThread();
    /// Инициализируем коллекцию сообщений ВФСВ ТВФ ( запрашиваем из БД ( Tlk ) )
    QVector < QByteArray > vfsvMsgs( selectFromInMSGZip ( "514949" ) );
    /// Выводим коллекцию сообщений ВФСВ ТВФ
    qDebug() << __PRETTY_FUNCTION__ << "[TVF VFSV MSGS] =>" << vfsvMsgs;
    /// Посылаем данные из потока БД в поток gui для заполнения форм
    emit signalMSGVfsvDataZip(vfsvMsgs);
    /// Сигнализируем о завершении работы метода
    qDebug() << __PRETTY_FUNCTION__<<"End" <<QThread::currentThread();

}

/// Запрос сообщений ВФСВ для zip
void CSqlDatabase::selectMsgVfvpZip()
{
    qDebug() << __PRETTY_FUNCTION__;
    /// Запускаем выборку сообщения из БД в поток подключения к БД
    /// Проверяем перенаправление в поток БД
    qDebug() << __PRETTY_FUNCTION__<<"StartZIP" <<QThread::currentThread();
    /// Инициализируем коллекцию сообщений ВФСВ ТВФ ( запрашиваем из БД ( Tlk ) )
    QVector < QByteArray > vfvpMsgs( selectFromInMSGZip ( "515249" ) );
    /// Выводим коллекцию сообщений ВФСВ ТВФ
    qDebug() << __PRETTY_FUNCTION__ << "[TVF VFSV MSGS] =>" << vfvpMsgs;
    /// Посылаем данные из потока БД в поток gui для заполнения форм
    emit signalMSGVfvpDataZip(vfvpMsgs);
    /// Сигнализируем о завершении работы метода
    qDebug() << __PRETTY_FUNCTION__<<"End" <<QThread::currentThread();

}
/// Запрос сообщений ВФСВ для zip
void CSqlDatabase::selectMsgKsiZip()
{
    qDebug() << __PRETTY_FUNCTION__;
    /// Запускаем выборку сообщения из БД в поток подключения к БД
    /// Проверяем перенаправление в поток БД
    qDebug() << __PRETTY_FUNCTION__<<"Start" <<QThread::currentThread();
    /// Инициализируем коллекцию сообщений ВФСВ ТВФ ( запрашиваем из БД ( Tlk ) )
    // selectInMSG_ksi("27");
    QByteArray  ksiMsgs( selectFromInMSGKSIZip ( "27" ) );
   // QTimer::singleShot(100,this,&CSqlDatabase::selectInMSG_ksiZip);
    /// Выводим коллекцию сообщений ВФСВ ТВФ
    qDebug() << __PRETTY_FUNCTION__ << "[TVF KSI MSGS] =>" << ksiMsgs;
    /// Посылаем данные из потока БД в поток gui для заполнения форм
    // int messageCount = 1;
    emit signalMSGKsiDataZip(ksiMsgs);
    /// Сигнализируем о завершении работы метода
    qDebug() << __PRETTY_FUNCTION__<<"End" <<QThread::currentThread();

}


/// Запрос сообщений ВФВП
void CSqlDatabase::selectMsgVfvp()
{
    qDebug() << __PRETTY_FUNCTION__;
    /// Запускаем выборку сообщения из БД в поток подключения к БД
    /// Проверяем перенаправление в поток БД
    qDebug() << __PRETTY_FUNCTION__<<"Start" <<QThread::currentThread();
    /// инициализируем коллекцию сообщений ВФВП ТВФ ( запрашиваем из БД ( Tlk ) )
    QVector < QByteArray > vfvpMsgs( selectFromInMSG ( "515249" ) );
    /// выводим коллекцию сообщений ВФВП ТВФ
    qDebug() << __PRETTY_FUNCTION__ << "[TVF VFVP MSGS] =>" << vfvpMsgs;
    /// Посылаем данные из потока БД в поток gui для заполнения форм
    emit signalMSGVfvpData(vfvpMsgs);
    /// Сигнализируем о завершении работы метода
    qDebug() << __PRETTY_FUNCTION__<<"End" <<QThread::currentThread();
}
/// Запрос сообщений ВФСВ (Файловая система)
//void CSqlDatabase::selectMsgVfsvFS()
//{
//    qDebug() << __PRETTY_FUNCTION__;
//    /// Запускаем выборку сообщения из БД в поток подключения к БД
//    /// Проверяем перенаправление в поток БД
//    qDebug() << __PRETTY_FUNCTION__<<"Start" <<QThread::currentThread();
//    /// Инициализируем коллекцию сообщений ВФСВ ТВФ ( запрашиваем из БД ( Tlk ) )
//    QVector < QByteArray > vfsvMsgs( selectFromOutMSGFs ( "514949" ) );
//    /// Выводим коллекцию сообщений ВФСВ ТВФ
//    qDebug() << __PRETTY_FUNCTION__ << "[TVF VFSV MSGS] =>" << vfsvMsgs;
//    /// Посылаем данные из потока БД в поток gui для заполнения форм
//    emit signalMSGVfsvDataFS(vfsvMsgs);
//    /// Сигнализируем о завершении работы метода
//    qDebug() << __PRETTY_FUNCTION__<<"End" <<QThread::currentThread();

//}
/// Запрос сообщений КСИ
void CSqlDatabase::selectMsgKsi()
{
    qDebug() << __PRETTY_FUNCTION__;
    /// Запускаем выборку сообщения из БД в поток подключения к БД
    /// Проверяем перенаправление в поток БД
    qDebug() << __PRETTY_FUNCTION__<<"Start" <<QThread::currentThread();
    /// Инициализируем коллекцию сообщений ВФСВ ТВФ ( запрашиваем из БД ( Tlk ) )
   // selectInMSG_ksi("27");
    QByteArray  ksiMsgs( selectFromInMSGKSI ( "27" ) );
    // QTimer::singleShot(100,this,&CSqlDatabase::selectInMSG_ksi);
    /// Выводим коллекцию сообщений ВФСВ ТВФ
    qDebug() << __PRETTY_FUNCTION__ << "[TVF KSI MSGS] =>" << ksiMsgs;
    /// Посылаем данные из потока БД в поток gui для заполнения форм
   // int messageCount = 1;
    emit signalMSGKsiData(ksiMsgs);
    /// Сигнализируем о завершении работы метода
    qDebug() << __PRETTY_FUNCTION__<<"End" <<QThread::currentThread();

}
/// Запрос сообщений КСИ (Файловая система)
//void CSqlDatabase::selectMsgFSKsi()
//{
//    qDebug() << __PRETTY_FUNCTION__;
//    /// Запускаем выборку сообщения из БД в поток подключения к БД
//    /// Проверяем перенаправление в поток БД
//    qDebug() << __PRETTY_FUNCTION__<<"StartFSKSI" <<QThread::currentThread();
//    /// Инициализируем коллекцию сообщений ВФСВ ТВФ ( запрашиваем из БД ( Tlk ) )
//    QVector < QByteArray > ksiMsgs( selectFromOutMSGFsKSI ( "27" ) );
//    /// Выводим коллекцию сообщений ВФСВ ТВФ
//    qDebug() << __PRETTY_FUNCTION__ << "[TVF KSIFS MSGS] =>" << ksiMsgs;
//    /// Посылаем данные из потока БД в поток gui для заполнения форм
//    int messageCount = 1;
//    emit signalMSGKsiDataFS(ksiMsgs, messageCount);
//    /// Сигнализируем о завершении работы метода
//    qDebug() << __PRETTY_FUNCTION__<<"End" <<QThread::currentThread();

//}
/// Запрос сообщений КСИ (UDP)
//void CSqlDatabase::selectMsgUDPKsi()
//{
//    qDebug() << __PRETTY_FUNCTION__;
//    /// Запускаем выборку сообщения из БД в поток подключения к БД
//    /// Проверяем перенаправление в поток БД
//    qDebug() << __PRETTY_FUNCTION__<<"StartUDPKSI" <<QThread::currentThread();
//    /// Инициализируем коллекцию сообщений ВФСВ ТВФ ( запрашиваем из БД ( Tlk ) )
//    QVector < QByteArray > ksiMsgs( selectFromOutMSGUdpKSI ( "27" ) );
//    /// Выводим коллекцию сообщений ВФСВ ТВФ
//    qDebug() << __PRETTY_FUNCTION__ << "[TVF KSIUDP MSGS] =>" << ksiMsgs;
//    /// Посылаем данные из потока БД в поток gui для заполнения форм
//    int messageCount = 1;
//    emit signalMSGKsiDataUDP(ksiMsgs, messageCount);
//    /// Сигнализируем о завершении работы метода
//    qDebug() << __PRETTY_FUNCTION__<<"End" <<QThread::currentThread();

//}
/// Запрос сообщений КСИ (UDP)
//void CSqlDatabase::selectMsgTCPKsi()
//{
//    qDebug() << __PRETTY_FUNCTION__;
//    /// Запускаем выборку сообщения из БД в поток подключения к БД
//    /// Проверяем перенаправление в поток БД
//    qDebug() << __PRETTY_FUNCTION__<<"StartTCPKSI" <<QThread::currentThread();
//    /// Инициализируем коллекцию сообщений ВФСВ ТВФ ( запрашиваем из БД ( Tlk ) )
//   // QVector < QByteArray > ksiMsgs( selectFromOutMSGTcpKSI ( "27" ) );
//     QByteArray  ksiMsgs( selectFromOutMSGTcpKSI ( "27" ) );
//    /// Выводим коллекцию сообщений ВФСВ ТВФ
//    qDebug() << __PRETTY_FUNCTION__ << "[TVF KSIUDP MSGS] =>" << ksiMsgs;
//    /// Посылаем данные из потока БД в поток gui для заполнения форм
//    int messageCount = 1;
//    emit signalMSGKsiDataTCP(ksiMsgs, messageCount);
//    /// Сигнализируем о завершении работы метода
//    qDebug() << __PRETTY_FUNCTION__<<"End" <<QThread::currentThread();

//}
/// Запрос сообщений ВФВП (Файловая система)
void CSqlDatabase::selectMsgVfvpFS()
{
    qDebug() << __PRETTY_FUNCTION__;
    /// Запускаем выборку сообщения из БД в поток подключения к БД
    /// Проверяем перенаправление в поток БД
    qDebug() << __PRETTY_FUNCTION__<<"Start" <<QThread::currentThread();
    /// инициализируем коллекцию сообщений ВФВП ТВФ ( запрашиваем из БД ( Tlk ) )
    QVector < QByteArray > vfvpMsgs( selectFromOutMSGFs ( "515249" ) );
    /// выводим коллекцию сообщений ВФВП ТВФ
    qDebug() << __PRETTY_FUNCTION__ << "[TVF VFVP MSGS] =>" << vfvpMsgs;
    /// Посылаем данные из потока БД в поток gui для заполнения форм
    emit signalMSGVfvpDataFS(vfvpMsgs);
    /// Сигнализируем о завершении работы метода
    qDebug() << __PRETTY_FUNCTION__<<"End" <<QThread::currentThread();
}
/// Запрос сообщений ВФСВ (UDP канал)
//void CSqlDatabase::selectMsgVfsvUDP()
//{
//    qDebug() << __PRETTY_FUNCTION__;
//    /// Запускаем выборку сообщения из БД в поток подключения к БД
//    /// Проверяем перенаправление в поток БД
//    qDebug() << __PRETTY_FUNCTION__<<"Start" <<QThread::currentThread();
//    /// Инициализируем коллекцию сообщений ВФСВ ТВФ ( запрашиваем из БД ( Tlk ) )
//    QVector < QByteArray > vfsvMsgs( selectFromOutMSGUdp ( "514949" ) );
//    /// Выводим коллекцию сообщений ВФСВ ТВФ
//    qDebug() << __PRETTY_FUNCTION__ << "[TVF VFSV MSGS] =>" << vfsvMsgs;
//    /// Посылаем данные из потока БД в поток gui для заполнения форм
//    emit signalMSGVfsvDataUDP(vfsvMsgs);
//    /// Сигнализируем о завершении работы метода
//    qDebug() << __PRETTY_FUNCTION__<<"End" <<QThread::currentThread();

//}
/// Запрос сообщений ВФВП (UDP канал)
void CSqlDatabase::selectMsgVfvpUDP()
{
    qDebug() << __PRETTY_FUNCTION__;
    /// Запускаем выборку сообщения из БД в поток подключения к БД
    /// Проверяем перенаправление в поток БД
    qDebug() << __PRETTY_FUNCTION__<<"Start" <<QThread::currentThread();
    /// инициализируем коллекцию сообщений ВФВП ТВФ ( запрашиваем из БД ( Tlk ) )
    QVector < QByteArray > vfvpMsgs( selectFromOutMSGUdp ( "515249" ) );
    /// выводим коллекцию сообщений ВФВП ТВФ
    qDebug() << __PRETTY_FUNCTION__ << "[TVF VFVP MSGS] =>" << vfvpMsgs;
    /// Посылаем данные из потока БД в поток gui для заполнения форм
    emit signalMSGVfvpDataUDP(vfvpMsgs);
    /// Сигнализируем о завершении работы метода
    qDebug() << __PRETTY_FUNCTION__<<"End" <<QThread::currentThread();
}
/// Запрос сообщений ВФСВ (TCP канал)
//void CSqlDatabase::selectMsgVfsvTCP()
//{
//    qDebug() << __PRETTY_FUNCTION__;
//    /// Запускаем выборку сообщения из БД в поток подключения к БД
//    /// Проверяем перенаправление в поток БД
//    qDebug() << __PRETTY_FUNCTION__<<"Start" <<QThread::currentThread();
//    /// Инициализируем коллекцию сообщений ВФСВ ТВФ ( запрашиваем из БД ( Tlk ) )
//    QVector < QByteArray > vfsvMsgs( selectFromOutMSGTcp ( "514949" ) );
//    /// Выводим коллекцию сообщений ВФСВ ТВФ
//    qDebug() << __PRETTY_FUNCTION__ << "[TVF VFSV MSGS] =>" << vfsvMsgs;
//    /// Посылаем данные из потока БД в поток gui для заполнения форм
//    emit signalMSGVfsvDataTCP(vfsvMsgs);
//    /// Сигнализируем о завершении работы метода
//    qDebug() << __PRETTY_FUNCTION__<<"End" <<QThread::currentThread();

//}
/// Запрос сообщений ВФВП (TCP канал)
void CSqlDatabase::selectMsgVfvpTCP()
{
    qDebug() << __PRETTY_FUNCTION__;
    /// Запускаем выборку сообщения из БД в поток подключения к БД
    /// Проверяем перенаправление в поток БД
    qDebug() << __PRETTY_FUNCTION__<<"Start" <<QThread::currentThread();
    /// инициализируем коллекцию сообщений ВФВП ТВФ ( запрашиваем из БД ( Tlk ) )
    QVector < QByteArray > vfvpMsgs( selectFromOutMSGTcp ( "515249" ) );
    /// выводим коллекцию сообщений ВФВП ТВФ
    qDebug() << __PRETTY_FUNCTION__ << "[TVF VFVP MSGS] =>" << vfvpMsgs;
    /// Посылаем данные из потока БД в поток gui для заполнения форм
    emit signalMSGVfvpDataTCP(vfvpMsgs);
    /// Сигнализируем о завершении работы метода
    qDebug() << __PRETTY_FUNCTION__<<"End" <<QThread::currentThread();
}
/// Получение данных из БД
QVector < QByteArray > CSqlDatabase::selectFromInMSG( const QString &msgSubtype )
{
    /// создаем пустой вектор данных
    QVector < QByteArray >  dataVector;
    /// инициализируем запрос к базе данных
    QSqlQuery sqlQuery( mASUVDataBase_ );
    /// задаем запрос к базе данных
    sqlQuery.prepare( "SELECT in_msg_buff.msg_id,in_msg_data.msg_data FROM "
                     "in_msg_data,in_msg_buff "
                     "WHERE in_msg_buff.msg_id = in_msg_data.msg_id AND in_msg_buff.msg_subtype = :msgSubtype "
                     "LIMIT 1" );
    /// задаем подтип сообщения
    sqlQuery.bindValue( ":msgSubtype", msgSubtype );
    /// выполняем запрос к базе данных
    if( !sqlQuery.exec() ) {
        qDebug() << __PRETTY_FUNCTION__ << sqlQuery.lastQuery() << sqlQuery.lastError();
        /// возвращаем пустой вектор данных
        return dataVector;
    }
    QStringList idLst; /// инициализируем индексы обработанных сообщений
    /// получаем сообщения
    while ( sqlQuery.next() ) {
        /// задаем вектор данных
        dataVector.append( sqlQuery.value( 1 ).toByteArray() );
        /// задаем индексы обработанных сообщений
        idLst.append( sqlQuery.value( 0 ).toString() );
    }
    /// удаляем обработанные сообщения
    deleteFromInMSG( idLst );
    ///посылаем сигнал что произошла выборка сообщения
    qDebug() << __PRETTY_FUNCTION__ << msgSubtype<<"!!!!!!!!!!!!!!!!!!!!!!!!!";
    emit inSignalOnDeleteMSG(msgSubtype);
    /// возвращаем вектор данных
    return dataVector;
}

/// Получение данных из БД
QVector < QByteArray > CSqlDatabase::selectFromInMSGZip( const QString &msgSubtype )
{
    /// создаем пустой вектор данных
    QVector < QByteArray >  dataVector;
    /// инициализируем запрос к базе данных
    QSqlQuery sqlQuery( mASUVDataBase_ );

    /// задаем запрос к базе данных
     sqlQuery.prepare("SELECT in_msg_buff.msg_id, in_msg_data.msg_data FROM "
                     "in_msg_data, in_msg_buff "
                     "WHERE in_msg_buff.msg_id = in_msg_data.msg_id AND in_msg_buff.msg_subtype = :msgSubtype AND in_msg_buff.msg_zip = FALSE "
                     "LIMIT 100");

    /// задаем подтип сообщения
     sqlQuery.bindValue( ":msgSubtype", msgSubtype);
    /// выполняем запрос к базе данных
    if( !sqlQuery.exec() ) {
        qDebug() << __PRETTY_FUNCTION__ << sqlQuery.lastQuery() << sqlQuery.lastError();
        /// возвращаем пустой вектор данных
        return dataVector;
    }
    QStringList idLst; /// инициализируем индексы обработанных сообщений
    /// получаем сообщения
    while ( sqlQuery.next() ) {
        /// задаем вектор данных
        dataVector.append( sqlQuery.value( 1 ).toByteArray() );
        /// задаем индексы обработанных сообщений
        idLst.append( sqlQuery.value( 0 ).toString() );
        qDebug() << __PRETTY_FUNCTION__<<"FFGTGGGGGGFFFFFFFFFFFFFFFFFFF" << idLst;
    }
    /// помечаем обработанные сообщения
    updateFromInMSG( idLst );
    ///посылаем сигнал что произошла выборка сообщения
    qDebug() << __PRETTY_FUNCTION__ << msgSubtype<<"!!!!!!!!!!!!!!!!!!!!!!!!!";
   // emit inSignalOnDeleteMSG(msgSubtype);
    /// возвращаем вектор данных
    return dataVector;
}

    /// Помечаем выбранные сообщения как прочитанные
void CSqlDatabase::updateFromInMSG(const QStringList &idLst)
{
    /// проверка на пустой список сообщений на удаление
    if ( idLst.isEmpty() ) return;
    for (const QString& msgId : idLst) {
    QSqlQuery updateQuery( mASUVDataBase_ );
    updateQuery.prepare("UPDATE in_msg_buff SET msg_zip = TRUE WHERE msg_id = :msgId");
    updateQuery.bindValue(":msgId", msgId);
    if (!updateQuery.exec()) {
        qDebug() << "Ошибка пометки выбранных сообщений!" << updateQuery.lastError();
        // Обработка ошибки при неудачном выполнении запроса UPDATE
    }
}
}
/// Получение данных из БД
QVector < QByteArray > CSqlDatabase::selectFromOutMSGFs( const QString &msgSubtype )
{
    /// создаем пустой вектор данных
    QVector < QByteArray >  dataVector;
    /// инициализируем запрос к базе данных
    QSqlQuery sqlQuery( mASUVDataBase_ );
    /// задаем запрос к базе данных
    sqlQuery.prepare( "SELECT out_msg_buff_fs.msg_id,out_msg_data.msg_data FROM "
                     "out_msg_data,out_msg_buff_fs "
                     "WHERE out_msg_buff_fs.msg_id = out_msg_data.msg_id AND out_msg_buff_fs.msg_subtype = :msgSubtype "
                     "LIMIT 1" );
    /// задаем подтип сообщения
    sqlQuery.bindValue( ":msgSubtype", msgSubtype );
    /// выполняем запрос к базе данных
    if( !sqlQuery.exec() ) {
        qDebug() << __PRETTY_FUNCTION__ << sqlQuery.lastQuery() << sqlQuery.lastError();
        /// возвращаем пустой вектор данных
        return dataVector;
    }
    QStringList idLstfs; /// инициализируем индексы обработанных сообщений
    /// получаем сообщения
    while ( sqlQuery.next() ) {
        /// задаем вектор данных
        dataVector.append( sqlQuery.value( 1 ).toByteArray() );
        /// задаем индексы обработанных сообщений
        idLstfs.append( sqlQuery.value( 0 ).toString() );
    }
    /// удаляем обработанные сообщения
    deleteFromOutMSGFs( idLstfs );
    ///посылаем сигнал что произошла выборка сообщения
    emit outSignalOnDeleteMSGFs(msgSubtype);
    /// возвращаем вектор данных
    return dataVector;
}

/// Получение данных из БД
QVector < QByteArray > CSqlDatabase::selectFromOutMSGUdp( const QString &msgSubtype )
{
    /// создаем пустой вектор данных
    QVector < QByteArray >  dataVector;
    /// инициализируем запрос к базе данных
    QSqlQuery sqlQuery( mASUVDataBase_ );
    /// задаем запрос к базе данных
    sqlQuery.prepare( "SELECT out_msg_buff_udp.msg_id,out_msg_data.msg_data FROM "
                     "out_msg_data,out_msg_buff_udp "
                     "WHERE out_msg_buff_udp.msg_id = out_msg_data.msg_id AND out_msg_buff_udp.msg_subtype = :msgSubtype "
                     "LIMIT 1" );
    /// задаем подтип сообщения
    sqlQuery.bindValue( ":msgSubtype", msgSubtype );
    /// выполняем запрос к базе данных
    if( !sqlQuery.exec() ) {
        qDebug() << __PRETTY_FUNCTION__ << sqlQuery.lastQuery() << sqlQuery.lastError();
        /// возвращаем пустой вектор данных
        return dataVector;
    }
    QStringList idLstudp; /// инициализируем индексы обработанных сообщений
    /// получаем сообщения
    while ( sqlQuery.next() ) {
        /// задаем вектор данных
        dataVector.append( sqlQuery.value( 1 ).toByteArray() );
        /// задаем индексы обработанных сообщений
        idLstudp.append( sqlQuery.value( 0 ).toString() );
    }
    /// удаляем обработанные сообщения
    deleteFromOutMSGUdp( idLstudp );
    ///посылаем сигнал что произошла выборка сообщения
    emit outSignalOnDeleteMSGUdp(msgSubtype);
    /// возвращаем вектор данных
    return dataVector;
}
/// Получение данных из БД
QVector < QByteArray > CSqlDatabase::selectFromOutMSGTcp( const QString &msgSubtype )
{
    /// создаем пустой вектор данных
    QVector < QByteArray >  dataVector;
    /// инициализируем запрос к базе данных
    QSqlQuery sqlQuery( mASUVDataBase_ );
    /// задаем запрос к базе данных
    sqlQuery.prepare( "SELECT out_msg_buff_tcp.msg_id,out_msg_data.msg_data FROM "
                     "out_msg_data,out_msg_buff_tcp "
                     "WHERE out_msg_buff_tcp.msg_id = out_msg_data.msg_id AND out_msg_buff_tcp.msg_subtype = :msgSubtype "
                     "LIMIT 1" );
    /// задаем подтип сообщения
    sqlQuery.bindValue( ":msgSubtype", msgSubtype );
    /// выполняем запрос к базе данных
    if( !sqlQuery.exec() ) {
        qDebug() << __PRETTY_FUNCTION__ << sqlQuery.lastQuery() << sqlQuery.lastError();
        /// возвращаем пустой вектор данных
        return dataVector;
    }
    QStringList idLsttcp; /// инициализируем индексы обработанных сообщений
    /// получаем сообщения
    while ( sqlQuery.next() ) {
        /// задаем вектор данных
        dataVector.append( sqlQuery.value( 1 ).toByteArray() );
        /// задаем индексы обработанных сообщений
        idLsttcp.append( sqlQuery.value( 0 ).toString() );
    }
    /// удаляем обработанные сообщения
    deleteFromOutMSGTcp( idLsttcp );
    ///посылаем сигнал что произошла выборка сообщения
    emit outSignalOnDeleteMSGTcp(msgSubtype);
    /// возвращаем вектор данных
    return dataVector;
}
/// Получение данных из БД
QByteArray  CSqlDatabase::selectFromInMSGKSI( const QString &msgType )
{
    /// создаем пустой вектор данных
    QByteArray  dataVector;
    /// инициализируем запрос к базе данных
    QSqlQuery sqlQuery( mASUVDataBase_ );
    /// задаем запрос к базе данных
    sqlQuery.prepare( "SELECT in_msg_buff.msg_id,in_msg_data.msg_data FROM "
                     "in_msg_data,in_msg_buff "
                     "WHERE in_msg_buff.msg_id = in_msg_data.msg_id AND in_msg_buff.msg_type = :msgType "
                     "LIMIT 1" );
    /// задаем тип сообщения
    sqlQuery.bindValue( ":msgType", msgType );
    /// выполняем запрос к базе данных
    if( !sqlQuery.exec() ) {
        qDebug() << __PRETTY_FUNCTION__ << sqlQuery.lastQuery() << sqlQuery.lastError();
        /// возвращаем пустой вектор данных
        return dataVector;
    }

    QStringList idLstKSI; /// инициализируем индексы обработанных сообщений
    /// получаем сообщения
    while ( sqlQuery.next() ) {
        /// задаем вектор данных
        dataVector.append( sqlQuery.value( 1 ).toByteArray() );
        /// задаем индексы обработанных сообщений
        idLstKSI.append( sqlQuery.value( 0 ).toString() );
    }

    deleteFromInMSGKsi( idLstKSI );

    ///посылаем сигнал что произошла выборка сообщения
    qDebug() << __PRETTY_FUNCTION__ << msgType<< "!!!!!!!!!!!!!!!!!!!!!!!!!";
    /// сигнал каунтера
    emit inSignalOnDeleteMSGKsi(msgType);
    /// возвращаем вектор данных
    return dataVector;
}
/// Получение данных из БД
QByteArray  CSqlDatabase::selectFromInMSGKSIZip( const QString &msgType )
{
    /// создаем пустой вектор данных
    QByteArray  dataVector;
    /// инициализируем запрос к базе данных
    QSqlQuery sqlQuery( mASUVDataBase_ );
    /// задаем запрос к базе данных
    sqlQuery.prepare( "SELECT in_msg_buff.msg_id,in_msg_data.msg_data FROM "
                     "in_msg_data,in_msg_buff "
                     "WHERE in_msg_buff.msg_id = in_msg_data.msg_id AND in_msg_buff.msg_type = :msgType AND in_msg_buff.msg_zip = FALSE "
                     "LIMIT 100" );

    /// задаем тип сообщения
    sqlQuery.bindValue( ":msgType", msgType );
    /// выполняем запрос к базе данных
    if( !sqlQuery.exec() ) {
        qDebug() << __PRETTY_FUNCTION__ << sqlQuery.lastQuery() << sqlQuery.lastError();
        /// возвращаем пустой вектор данных
        return dataVector;
    }

    QStringList idLstKSIzip; /// инициализируем индексы обработанных сообщений
    /// получаем сообщения
    while ( sqlQuery.next() ) {
        /// задаем вектор данных
        dataVector.append( sqlQuery.value( 1 ).toByteArray() );
        /// задаем индексы обработанных сообщений
        idLstKSIzip.append( sqlQuery.value( 0 ).toString() );
    }
    /// помечаем обработанные сообщения
    updateFromInMSGKsi( idLstKSIzip );
    ///посылаем сигнал что произошла выборка сообщения
    qDebug() << __PRETTY_FUNCTION__ << msgType<< "!!!!!!!!!!!!!!!!!!!!!!!!!";
    /// сигнал каунтера
   // emit inSignalOnDeleteMSGKsi(msgType);
    /// возвращаем вектор данных
    return dataVector;
}

/// Помечаем выбранные сообщения как прочитанные
void CSqlDatabase::updateFromInMSGKsi(const QStringList &idLstKSIzip)
{
    /// проверка на пустой список сообщений на удаление
    if ( idLstKSIzip.isEmpty() ) return;
    for (const QString& msgId : idLstKSIzip) {
        QSqlQuery updateQuery( mASUVDataBase_ );
        updateQuery.prepare("UPDATE in_msg_buff SET msg_zip = TRUE WHERE msg_id = :msgId");
        updateQuery.bindValue(":msgId", msgId);
        if (!updateQuery.exec()) {
        qDebug() << "Ошибка пометки выбранных сообщений!" << updateQuery.lastError();
        // Обработка ошибки при неудачном выполнении запроса UPDATE
        }
    }
}
////////////////////////////////
QString CSqlDatabase::selectInMSG_ksi( )
{
    QString subTypeKsi;
    const QString msgType = "27";
    /// инициализируем запрос к базе данных
    QSqlQuery sqlQuery( mASUVDataBase_ );

    sqlQuery.prepare("SELECT in_msg_buff.msg_subtype FROM in_msg_buff WHERE in_msg_buff.msg_type = '" + msgType + "' LIMIT 1");
    if (sqlQuery.exec()) {
        while (sqlQuery.next()) {
            subTypeKsi = sqlQuery.value(0).toString();
        }
    } else {
        qDebug() << sqlQuery.lastError().text();
    }
    qDebug() << __PRETTY_FUNCTION__ << msgType << "Подтип КСИ =>" << subTypeKsi;
    /// сигнал подтипа кси
    emit signalNEWKsi(subTypeKsi);
    /// удаляем обработанные сообщения
    // deleteFromInMSGKsi( idLstKSI );
   return subTypeKsi;
}

//QString CSqlDatabase::selectInMSG_ksiZip( )
//{
//   QString subTypeKsi;
//   const QString msgType = "27";
//   /// инициализируем запрос к базе данных
//   QSqlQuery sqlQuery( mASUVDataBase_ );

//   sqlQuery.prepare("SELECT in_msg_buff.msg_subtype FROM in_msg_buff WHERE in_msg_buff.msg_type = '" + msgType + "' LIMIT 1");
//   if (sqlQuery.exec()) {
//        while (sqlQuery.next()) {
//            subTypeKsi = sqlQuery.value(0).toString();
//        }
//   } else {
//        qDebug() << sqlQuery.lastError().text();
//   }
//   qDebug() << __PRETTY_FUNCTION__ << msgType << "Подтип КСИ =>" << subTypeKsi;
//           /// сигнал подтипа кси
//          // emit signalNEWKsi(subTypeKsi);//////////////
//   /// удаляем обработанные сообщения
//   //deleteFromInMSGKsi( idLstKSI );
//   return subTypeKsi;
//}
////////////////////////////////////////////////////
/// Получение данных из БД
//QVector < QByteArray > CSqlDatabase::selectFromOutMSGFsKSI( const QString &msgType )
//{
//    /// создаем пустой вектор данных
//    QVector < QByteArray >  dataVector;
//    /// инициализируем запрос к базе данных
//    QSqlQuery sqlQuery( mASUVDataBase_ );
//    /// задаем запрос к базе данных
//    sqlQuery.prepare( "SELECT out_msg_buff_fs.msg_id,out_msg_data.msg_data FROM "
//                     "out_msg_data,out_msg_buff_fs "
//                     "WHERE out_msg_buff_fs.msg_id = out_msg_data.msg_id AND out_msg_buff_fs.msg_type = :msgType "
//                     "LIMIT 1" );
//    /// задаем подтип сообщения
//    sqlQuery.bindValue( ":msgType", msgType );
//    /// выполняем запрос к базе данных
//    if( !sqlQuery.exec() ) {
//        qDebug() << __PRETTY_FUNCTION__ << sqlQuery.lastQuery() << sqlQuery.lastError();
//        /// возвращаем пустой вектор данных
//        return dataVector;
//    }
//    QStringList idLstfs; /// инициализируем индексы обработанных сообщений
//    /// получаем сообщения
//    while ( sqlQuery.next() ) {
//        /// задаем вектор данных
//        dataVector.append( sqlQuery.value( 1 ).toByteArray() );
//        /// задаем индексы обработанных сообщений
//        idLstfs.append( sqlQuery.value( 0 ).toString() );
//    }
//    /// удаляем обработанные сообщения
//    deleteFromOutMSGFsKsi( idLstfs );///////////////////
//    ///посылаем сигнал что произошла выборка сообщения
//    emit outSignalOnDeleteMSGFsKsi(msgType);///////////////////////
//    /// возвращаем вектор данных
//    return dataVector;
//}
/// Получение данных из БД КСИ
//QVector < QByteArray > CSqlDatabase::selectFromOutMSGUdpKSI( const QString &msgType )
//{
//    /// создаем пустой вектор данных
//    QVector < QByteArray >  dataVector;
//    /// инициализируем запрос к базе данных
//    QSqlQuery sqlQuery( mASUVDataBase_ );
//    /// задаем запрос к базе данных
//    sqlQuery.prepare( "SELECT out_msg_buff_udp.msg_id,out_msg_data.msg_data FROM "
//                     "out_msg_data,out_msg_buff_udp "
//                     "WHERE out_msg_buff_udp.msg_id = out_msg_data.msg_id AND out_msg_buff_udp.msg_type = :msgType "
//                     "LIMIT 1" );
//    /// задаем подтип сообщения
//    sqlQuery.bindValue( ":msgType", msgType );
//    /// выполняем запрос к базе данных
//    if( !sqlQuery.exec() ) {
//        qDebug() << __PRETTY_FUNCTION__ << sqlQuery.lastQuery() << sqlQuery.lastError();
//        /// возвращаем пустой вектор данных
//        return dataVector;
//    }
//    QStringList idLstudp; /// инициализируем индексы обработанных сообщений
//    /// получаем сообщения
//    while ( sqlQuery.next() ) {
//        /// задаем вектор данных
//        dataVector.append( sqlQuery.value( 1 ).toByteArray() );
//        /// задаем индексы обработанных сообщений
//        idLstudp.append( sqlQuery.value( 0 ).toString() );
//    }
//    /// удаляем обработанные сообщения
//    deleteFromOutMSGUdpKsi( idLstudp );
//    ///посылаем сигнал что произошла выборка сообщения
//    emit outSignalOnDeleteMSGUdpKsi(msgType);
//    /// возвращаем вектор данных
//    return dataVector;
//}
/// Получение данных из БД КСИ
//QVector < QByteArray > CSqlDatabase::selectFromOutMSGTcpKSI( const QString &msgType )
//QByteArray  CSqlDatabase::selectFromOutMSGTcpKSI( const QString &msgType )
//{
//    /// создаем пустой вектор данных
//   // QVector < QByteArray >  dataVector;
//    QByteArray   dataVector;
//    /// инициализируем запрос к базе данных
//    QSqlQuery sqlQuery( mASUVDataBase_ );
//    /// задаем запрос к базе данных
//    sqlQuery.prepare( "SELECT out_msg_buff_tcp.msg_id,out_msg_data.msg_data FROM "
//                     "out_msg_data,out_msg_buff_tcp "
//                     "WHERE out_msg_buff_tcp.msg_id = out_msg_data.msg_id AND out_msg_buff_tcp.msg_type = :msgType "
//                     "LIMIT 1" );
//    /// задаем подтип сообщения
//    sqlQuery.bindValue( ":msgType", msgType );
//    /// выполняем запрос к базе данных
//    if( !sqlQuery.exec() ) {
//        qDebug() << __PRETTY_FUNCTION__ << sqlQuery.lastQuery() << sqlQuery.lastError();
//        /// возвращаем пустой вектор данных
//        return dataVector;
//    }
//    QStringList idLsttcp; /// инициализируем индексы обработанных сообщений
//    /// получаем сообщения
//    while ( sqlQuery.next() ) {
//        /// задаем вектор данных
//        dataVector.append( sqlQuery.value( 1 ).toByteArray() );
//        /// задаем индексы обработанных сообщений
//        idLsttcp.append( sqlQuery.value( 0 ).toString() );
//    }
//    /// удаляем обработанные сообщения
//    deleteFromOutMSGTcpKsi( idLsttcp );
//    ///посылаем сигнал что произошла выборка сообщения
//    emit outSignalOnDeleteMSGTcpKsi(msgType);
//    /// возвращаем вектор данных
//    return dataVector;
//}
/// Отправка сообщений через tlk
bool CSqlDatabase::sendViaTlkUDP(const QString    &msgUrgent, const QString     &msgMac    ,
                              const QString    &msgType  , const QString     &msgSubtype,
                              const QString    &msgTtl   , const QStringList &msgAddrLst,
                              const QString    &msgUser , const QByteArray &msgData )
{
    qDebug() << __PRETTY_FUNCTION__<<"Start sendXML" <<QThread::currentThread();
    /// инициализируем запрос к базе данных
    QSqlQuery sqlQuery( mASUVDataBase_ );
    /// задаем запрос к базе данных
    sqlQuery.prepare( "INSERT INTO send_msg "
                     "(msg_urgent, msg_mac, msg_type, msg_subtype, msg_ttl, "
                     "msg_address, msg_user, msg_uuid, msg_data) "
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)" );

    /// задаем категорию срочности
    sqlQuery.bindValue( 0, msgUrgent                                  );
    /// задаем мандатную метку
    sqlQuery.bindValue( 1, msgMac                                     );
    /// задаем тип сообщения
    sqlQuery.bindValue( 2, msgType                                    );
    /// задаем подтип сообщения
    sqlQuery.bindValue( 3, msgSubtype                                 );
    /// задаем время жизни сообщения
    sqlQuery.bindValue( 4, msgTtl                                     );
    /// задаем адрес(а) получателя(ей) сообщения ( несколько адресов получателей разделяются пробелом )
    sqlQuery.bindValue( 5, msgAddrLst.join( ' ' )                     );
    /// задаем пользователя, отправившего сообщение
    sqlQuery.bindValue( 6, msgUser );
    /// задаем уникальный идентификатор сообщения
    sqlQuery.bindValue( 7, QUuid::createUuid().toByteArray()          );
    /// задаем данные сообщения
    sqlQuery.bindValue( 8, msgData                                    );

    /// выполняем запрос к базе данных
    if ( !sqlQuery.exec() ) qDebug() << sqlQuery.lastQuery() << sqlQuery.lastError();

    /// возвращаем статус запроса к базе данных
    return !sqlQuery.last();
}
/// Отправка сообщений через tlk
bool CSqlDatabase::sendViaTlkTCP(const QString    &msgUrgent, const QString     &msgMac    ,
                                 const QString    &msgType  , const QString     &msgSubtype,
                                 const QString    &msgTtl   , const QStringList &msgAddrLst,
                                 const QString    &msgUser , const QByteArray &msgData )
{
    qDebug() << __PRETTY_FUNCTION__<<"Start sendXMLTCP" <<QThread::currentThread();
    /// инициализируем запрос к базе данных
    QSqlQuery sqlQuery( mASUVDataBase_ );
    /// задаем запрос к базе данных
    sqlQuery.prepare( "INSERT INTO send_msg "
                     "(msg_urgent, msg_mac, msg_type, msg_subtype, msg_ttl, "
                     "msg_address, msg_user, msg_uuid, msg_data) "
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)" );

    /// задаем категорию срочности
    sqlQuery.bindValue( 0, msgUrgent                                  );
    /// задаем мандатную метку
    sqlQuery.bindValue( 1, msgMac                                     );
    /// задаем тип сообщения
    sqlQuery.bindValue( 2, msgType                                    );
    /// задаем подтип сообщения
    sqlQuery.bindValue( 3, msgSubtype                                 );
    /// задаем время жизни сообщения
    sqlQuery.bindValue( 4, msgTtl                                     );
    /// задаем адрес(а) получателя(ей) сообщения ( несколько адресов получателей разделяются пробелом )
    sqlQuery.bindValue( 5, msgAddrLst.join( ' ' )                     );
    /// задаем пользователя, отправившего сообщение
    sqlQuery.bindValue( 6, msgUser );
    /// задаем уникальный идентификатор сообщения
    sqlQuery.bindValue( 7, QUuid::createUuid().toByteArray()          );
    /// задаем данные сообщения
    sqlQuery.bindValue( 8, msgData                                    );

    /// выполняем запрос к базе данных
    if ( !sqlQuery.exec() ) qDebug() << sqlQuery.lastQuery() << sqlQuery.lastError();

    /// возвращаем статус запроса к базе данных
    return !sqlQuery.last();
}
/// Отправка сообщений через tlk
bool CSqlDatabase::sendViaTlk( const QString    &msgUrgent, const QString     &msgMac,
                              const QString    &msgType, const QString     &msgSubtype,
                              const QString    &msgTtl, const QStringList &msgAddrLst,
                              const QByteArray &msgData)
{
    qDebug() << __PRETTY_FUNCTION__<<"Start send" <<QThread::currentThread();
    /// инициализируем запрос к базе данных
    QSqlQuery sqlQuery( mASUVDataBase_ );
    /// задаем запрос к базе данных
    sqlQuery.prepare( "INSERT INTO send_msg "
                     "(msg_urgent, msg_mac, msg_type, msg_subtype, msg_ttl, "
                     "msg_address, msg_user, msg_uuid, msg_data) "
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)" );

    /// задаем категорию срочности
    sqlQuery.bindValue( 0, msgUrgent                                  );
    /// задаем мандатную метку
    sqlQuery.bindValue( 1, msgMac                                     );
    /// задаем тип сообщения
    sqlQuery.bindValue( 2, msgType                                    );
    /// задаем подтип сообщения
    sqlQuery.bindValue( 3, msgSubtype                                 );
    /// задаем время жизни сообщения
    sqlQuery.bindValue( 4, msgTtl                                     );
    /// задаем адрес(а) получателя(ей) сообщения ( несколько адресов получателей разделяются пробелом )
    sqlQuery.bindValue( 5, msgAddrLst.join( ' ' )                     );
    /// задаем пользователя, отправившего сообщение
    sqlQuery.bindValue( 6, QString::fromLocal8Bit( getenv( "USER" ) ) );
    /// задаем уникальный идентификатор сообщения
    sqlQuery.bindValue( 7, QUuid::createUuid().toByteArray()          );
    /// задаем данные сообщения
    sqlQuery.bindValue( 8, msgData                                    );

    /// выполняем запрос к базе данных
    if ( !sqlQuery.exec() ) qDebug() << sqlQuery.lastQuery() << sqlQuery.lastError();

    /// возвращаем статус запроса к базе данных
    return !sqlQuery.last();
}
/// Возвращаем наименование кода классификатора
QString CSqlDatabase::klassName( const QString &klass, const QString &kod )
{
    /// инициализируем запрос к базе данных
    QSqlQuery sqlQuery( mPOVZDataBase_ );
    /// задаем запрос к базе данных
    sqlQuery.prepare( QString( "SELECT name FROM %1 WHERE kod = :kod" )
                         .arg( mKlassTableMap_.value( klass ) ) );
    sqlQuery.bindValue( ":kod", kod );
    /// выполняем запрос к базе данных
    if( !sqlQuery.exec() ) {
        qDebug() << __PRETTY_FUNCTION__ << sqlQuery.lastQuery() << sqlQuery.lastError();
        /// возвращаем пустую строку
        return QString();
    }
    /// возвращаем пустую строку
    if ( !sqlQuery.first() ) return QString();
    /// возвращаем наименование кода классификатора
    return sqlQuery.value( 0 ).toString();
}

/// Удаление обработанных сообщений
void CSqlDatabase::deleteFromInMSG(const QStringList &idLst)
{
    /// проверка на пустой список сообщений на удаление
    if ( idLst.isEmpty() ) return;

    QSqlQuery sqlQuery( mASUVDataBase_ );
    /// удаление обработанных сообщений
    if ( !sqlQuery.exec( QString( "DELETE FROM in_msg_buff WHERE msg_id IN (%1)" )
                           .arg( idLst.join( "," ) ) ) )
        qDebug() << __PRETTY_FUNCTION__ << sqlQuery.lastQuery() << sqlQuery.lastError();
}
/// Удаление обработанных сообщений (FS)
void CSqlDatabase::deleteFromOutMSGFs(const QStringList &idLstfs)
{
    /// проверка на пустой список сообщений на удаление
    if ( idLstfs.isEmpty() ) return;

    QSqlQuery sqlQuery( mASUVDataBase_ );
    /// удаление обработанных сообщений
    if ( !sqlQuery.exec( QString( "DELETE FROM out_msg_buff_fs WHERE msg_id IN (%1)" )
                           .arg( idLstfs.join( "," ) ) ) )
        qDebug() << __PRETTY_FUNCTION__ << sqlQuery.lastQuery() << sqlQuery.lastError();
}
/// Удаление обработанных сообщений (UDP)
void CSqlDatabase::deleteFromOutMSGUdp(const QStringList &idLstudp)
{
    /// проверка на пустой список сообщений на удаление
    if ( idLstudp.isEmpty() ) return;

    QSqlQuery sqlQuery( mASUVDataBase_ );
    /// удаление обработанных сообщений
    if ( !sqlQuery.exec( QString( "DELETE FROM out_msg_buff_udp WHERE msg_id IN (%1)" )
                           .arg( idLstudp.join( "," ) ) ) )
        qDebug() << __PRETTY_FUNCTION__ << sqlQuery.lastQuery() << sqlQuery.lastError();
}
/// Удаление обработанных сообщений (TCP)
void CSqlDatabase::deleteFromOutMSGTcp(const QStringList &idLsttcp)
{
    /// проверка на пустой список сообщений на удаление
    if ( idLsttcp.isEmpty() ) return;

    QSqlQuery sqlQuery( mASUVDataBase_ );
    /// удаление обработанных сообщений
    if ( !sqlQuery.exec( QString( "DELETE FROM out_msg_buff_tcp WHERE msg_id IN (%1)" )
                           .arg( idLsttcp.join( "," ) ) ) )

        qDebug() << __PRETTY_FUNCTION__ << sqlQuery.lastQuery() << sqlQuery.lastError();
}
/// Удаление обработанных сообщений КСИ (FS)
void CSqlDatabase::deleteFromInMSGKsi(const QStringList &idLst)
{
    /// проверка на пустой список сообщений на удаление
    if ( idLst.isEmpty() ) return;

    QSqlQuery sqlQuery( mASUVDataBase_ );
    /// удаление обработанных сообщений
    if ( !sqlQuery.exec( QString( "DELETE FROM in_msg_buff WHERE msg_id IN (%1)" )
                           .arg( idLst.join( "," ) ) ) )
        qDebug() << __PRETTY_FUNCTION__ << sqlQuery.lastQuery() << sqlQuery.lastError();
}
    /// Удаление обработанных сообщений КСИ (FS)
//    void CSqlDatabase::deleteFromOutMSGFsKsi(const QStringList &idLstfs)
//{
//    /// проверка на пустой список сообщений на удаление
//    if ( idLstfs.isEmpty() ) return;

//    QSqlQuery sqlQuery( mASUVDataBase_ );
//    /// удаление обработанных сообщений
//    if ( !sqlQuery.exec( QString( "DELETE FROM out_msg_buff_fs WHERE msg_id IN (%1)" )
//                           .arg( idLstfs.join( "," ) ) ) )
//        qDebug() << __PRETTY_FUNCTION__ << sqlQuery.lastQuery() << sqlQuery.lastError();
//}

/// Удаление обработанных сообщений КСИ (UDP)
//void CSqlDatabase::deleteFromOutMSGUdpKsi(const QStringList &idLstfs)
//{
//    /// проверка на пустой список сообщений на удаление
//    if ( idLstfs.isEmpty() ) return;

//    QSqlQuery sqlQuery( mASUVDataBase_ );
//    /// удаление обработанных сообщений
//    if ( !sqlQuery.exec( QString( "DELETE FROM out_msg_buff_udp WHERE msg_id IN (%1)" )
//                           .arg( idLstfs.join( "," ) ) ) )
//        qDebug() << __PRETTY_FUNCTION__ << sqlQuery.lastQuery() << sqlQuery.lastError();
//}

/// Удаление обработанных сообщений КСИ (TCP)
//void CSqlDatabase::deleteFromOutMSGTcpKsi(const QStringList &idLstfs)
//{
//    /// проверка на пустой список сообщений на удаление
//    if ( idLstfs.isEmpty() ) return;

//    QSqlQuery sqlQuery( mASUVDataBase_ );
//    /// удаление обработанных сообщений
//    if ( !sqlQuery.exec( QString( "DELETE FROM out_msg_buff_tcp WHERE msg_id IN (%1)" )
//                           .arg( idLstfs.join( "," ) ) ) )
//        qDebug() << __PRETTY_FUNCTION__ << sqlQuery.lastQuery() << sqlQuery.lastError();
//}
/// Задаем коллекцию таблиц классификаторов
void CSqlDatabase::initKlassTableMap()
{
    mKlassTableMap_.insert( "kdo_kod"     , "kdo"    );
    mKlassTableMap_.insert( "kod_kdols"   , "kdols"  );
    mKlassTableMap_.insert( "khdvf_kod"   , "khdvf"  );
    mKlassTableMap_.insert( "kod_khdvf"   , "khdvf"  );
    mKlassTableMap_.insert( "kio_kod"     , "kio"    );
    mKlassTableMap_.insert( "kir_kod"     , "kir"    );
    mKlassTableMap_.insert( "kod_kkls"    , "kkls"   );
    mKlassTableMap_.insert( "kkoovt_kod"  , "kkoovt" );
    mKlassTableMap_.insert( "kod_knshsp"  , "knshsp" );
    mKlassTableMap_.insert( "kpo_kod"     , "kpo"    );
    mKlassTableMap_.insert( "kod_kprv"    , "kprv"   );
    mKlassTableMap_.insert( "kod_kpvvs"   , "kpvvs"  );
    mKlassTableMap_.insert( "krvig_kod"   , "krvig"  );
    mKlassTableMap_.insert( "kod_ksbg"    , "ksbg"   );
    mKlassTableMap_.insert( "ksbs_kod"    , "ksbs"   );
    mKlassTableMap_.insert( "kod_ksbs"    , "ksbs"   );
    mKlassTableMap_.insert( "kod_ksmt"    , "ksmt"   );
    mKlassTableMap_.insert( "ksmt_kod"    , "ksmt"   );
    mKlassTableMap_.insert( "kod_ksuls"   , "ksuls"  );
    mKlassTableMap_.insert( "ksuo_kod"    , "ksuo"   );
    mKlassTableMap_.insert( "kod_ksuo"    , "ksuo"   );
    mKlassTableMap_.insert( "ktor_kod"    , "ktor"   );
    mKlassTableMap_.insert( "kod_ktpu"    , "ktpu"   );
    mKlassTableMap_.insert( "ktvfig_kod"  , "ktvfig" );
    mKlassTableMap_.insert( "kod_kuvf"    , "kuvf"   );
    mKlassTableMap_.insert( "kuvf_kod"    , "kuvf"   );
    mKlassTableMap_.insert( "kod_kvtmo"   , "kvtmo"  );
    mKlassTableMap_.insert( "kod_kvtmo_bp", "kvtmo"  );
    mKlassTableMap_.insert( "kvvsig_kod"  , "kvvsig" );
    mKlassTableMap_.insert( "kod_okei"    , "okei"   );
    mKlassTableMap_.insert( "kod_okogu"   , "okogu"  );
    mKlassTableMap_.insert( "kod_oksm"    , "oksm"   );
    mKlassTableMap_.insert( "oksm_kod"    , "oksm"   );
}


