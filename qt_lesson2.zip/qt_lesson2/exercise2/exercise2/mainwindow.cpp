#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QIcon>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui_(new Ui::MainWindow)
{
    ui_->setupUi(this);

    selection_model_.setModel(&model_);

    ui_->listView->setModel(&model_);
    ui_->listView->setSelectionModel(&selection_model_);
    ui_->listView->setSelectionMode(QAbstractItemView::SingleSelection);

    model_.appendRow(new QStandardItem(QIcon{":/cpp_icon.png"}, "C++"));
    model_.appendRow(new QStandardItem(QIcon{":/java_icon.png"},"Java"));
    model_.appendRow(new QStandardItem(QIcon{":/python_icon.png"}, "Python"));

    connect(ui_->iconModeCb, &QCheckBox::clicked, this, &MainWindow::onIconMode);
    connect(ui_->upButton, &QPushButton::clicked, this, &MainWindow::onUpButton);
    connect(ui_->downButton, &QPushButton::clicked, this, &MainWindow::onDownButton);
    connect(ui_->removeButton, &QPushButton::clicked, this, &MainWindow::onRemoveButton);
    connect(ui_->addButton, &QPushButton::clicked, this, &MainWindow::onAddButton);

    setWindowTitle("Lang list");
}

MainWindow::~MainWindow()
{
    delete ui_;
}

void MainWindow::onIconMode(bool checked)
{
    if (checked) {
        ui_->listView->setViewMode(QListView::IconMode);
    } else {
        ui_->listView->setViewMode(QListView::ListMode);
    }
}

void MainWindow::onUpButton()
{
    if (selection_model_.hasSelection()) {
        auto cur_ind = selection_model_.currentIndex();
        if (cur_ind.isValid()) {
            auto row = cur_ind.row();
            if (row > 0) {
                auto item = model_.takeRow(cur_ind.row());
                model_.insertRow(--row, item);
            }
            ui_->listView->setCurrentIndex(model_.index(row, 0));
        }
    }
}

void MainWindow::onDownButton()
{
    if (selection_model_.hasSelection()) {
        auto cur_ind = selection_model_.currentIndex();
        if (cur_ind.isValid()) {
            auto row = cur_ind.row();
            if (row < model_.rowCount() - 1) {
                auto item = model_.takeRow(cur_ind.row());
                model_.insertRow(++row, item);
            }
            ui_->listView->setCurrentIndex(model_.index(row, 0));
        }
    }
}

void MainWindow::onRemoveButton()
{
    if (selection_model_.hasSelection()) {
        auto cur_ind = selection_model_.currentIndex();
        if (cur_ind.isValid()) {
            model_.removeRow(cur_ind.row());
        }
    }
}

void MainWindow::onAddButton()
{
    if (!ui_->langNameEdit->text().isEmpty()) {
        model_.appendRow(new QStandardItem(QIcon{":/question_icon.png"}, ui_->langNameEdit->text()));
        ui_->langNameEdit->clear();
    }
}

